export const INITIAL_PARKING_LOCATIONS = [
  {
    id: "loc-101",
    title: "Rajiv Chowk Metro Private Underground Garage",
    ownerId: "owner-01",
    ownerName: "Rajesh Sharma",
    ownerContact: "+91 98765 43210",
    rating: 4.9,
    reviewsCount: 128,
    verified: true,
    address: "Block B, Inner Circle, Connaught Place, New Delhi",
    metroDistance: "120m from Gate 3 (Rajiv Chowk Metro)",
    lat: 28.6328,
    lng: 77.2197,
    image: "https://images.unsplash.com/photo-1506521781263-d8422e82f27a?auto=format&fit=crop&w=1000&q=80",
    type: "Underground Gated Complex",
    totalSlots: 12,
    availableSlots: 7,
    pricing: {
      hourly: 40,
      daily: 350,
      monthly: 6500,
      currency: "₹"
    },
    allowedVehicles: ["2-wheeler", "Sedan", "SUV", "EV"],
    amenities: ["24/7 Security Guard", "CCTV Surveillance", "EV Fast Charging", "Covered Roof", "Automated Boom Barrier"],
    operatingHours: "06:00 AM - 11:30 PM",
    slots: [
      { id: "A-01", type: "EV", vehicleCompatibility: ["EV", "Sedan"], status: "AVAILABLE", basePrice: 40 },
      { id: "A-02", type: "EV", vehicleCompatibility: ["EV", "SUV"], status: "OCCUPIED", basePrice: 45 },
      { id: "A-03", type: "4-Wheeler", vehicleCompatibility: ["Sedan", "SUV"], status: "AVAILABLE", basePrice: 40 },
      { id: "A-04", type: "4-Wheeler", vehicleCompatibility: ["Sedan", "SUV"], status: "AVAILABLE", basePrice: 40 },
      { id: "B-01", type: "2-Wheeler", vehicleCompatibility: ["2-wheeler"], status: "AVAILABLE", basePrice: 20 },
      { id: "B-02", type: "2-Wheeler", vehicleCompatibility: ["2-wheeler"], status: "AVAILABLE", basePrice: 20 },
      { id: "B-03", type: "2-Wheeler", vehicleCompatibility: ["2-wheeler"], status: "OCCUPIED", basePrice: 20 },
      { id: "C-01", type: "SUV Heavy", vehicleCompatibility: ["SUV"], status: "AVAILABLE", basePrice: 50 },
      { id: "C-02", type: "SUV Heavy", vehicleCompatibility: ["SUV"], status: "AVAILABLE", basePrice: 50 },
      { id: "C-03", type: "4-Wheeler", vehicleCompatibility: ["Sedan"], status: "OCCUPIED", basePrice: 40 },
      { id: "C-04", type: "4-Wheeler", vehicleCompatibility: ["Sedan"], status: "OCCUPIED", basePrice: 40 },
      { id: "C-05", type: "4-Wheeler", vehicleCompatibility: ["Sedan"], status: "OCCUPIED", basePrice: 40 }
    ]
  },
  {
    id: "loc-102",
    title: "DLF Cyber City Tech Tower Driveway",
    ownerId: "owner-02",
    ownerName: "Ananya Tech Hub Properties",
    ownerContact: "+91 99112 33445",
    rating: 4.8,
    reviewsCount: 94,
    verified: true,
    address: "DLF Cyber City Phase 2, Sector 24, Gurugram",
    metroDistance: "250m from Cyber City Rapid Metro",
    lat: 28.4950,
    lng: 77.0895,
    image: "https://images.unsplash.com/photo-1590674899484-d5640e854abe?auto=format&fit=crop&w=1000&q=80",
    type: "Commercial Office Driveway",
    totalSlots: 10,
    availableSlots: 4,
    pricing: {
      hourly: 50,
      daily: 450,
      monthly: 8000,
      currency: "₹"
    },
    allowedVehicles: ["2-wheeler", "Sedan", "SUV", "EV"],
    amenities: ["CCTV", "EV Fast Charging", "Valet Assistance", "Disabled Access"],
    operatingHours: "24/7 Open",
    slots: [
      { id: "S-101", type: "EV", vehicleCompatibility: ["EV"], status: "AVAILABLE", basePrice: 55 },
      { id: "S-102", type: "4-Wheeler", vehicleCompatibility: ["Sedan", "SUV"], status: "AVAILABLE", basePrice: 50 },
      { id: "S-103", type: "4-Wheeler", vehicleCompatibility: ["Sedan"], status: "OCCUPIED", basePrice: 50 },
      { id: "S-104", type: "2-Wheeler", vehicleCompatibility: ["2-wheeler"], status: "AVAILABLE", basePrice: 25 },
      { id: "S-105", type: "2-Wheeler", vehicleCompatibility: ["2-wheeler"], status: "AVAILABLE", basePrice: 25 },
      { id: "S-106", type: "SUV Heavy", vehicleCompatibility: ["SUV"], status: "OCCUPIED", basePrice: 60 }
    ]
  },
  {
    id: "loc-103",
    title: "Huda City Centre Smart Residency Bay",
    ownerId: "owner-03",
    ownerName: "Vikas Verma",
    ownerContact: "+91 98101 88776",
    rating: 4.7,
    reviewsCount: 62,
    verified: true,
    address: "Sector 29 Commercial Hub, Gurugram",
    metroDistance: "180m from Millenium City Centre Metro",
    lat: 28.4595,
    lng: 77.0725,
    image: "https://images.unsplash.com/photo-1573348722427-f1d6819fdf98?auto=format&fit=crop&w=1000&q=80",
    type: "Private Residential Gated Bay",
    totalSlots: 8,
    availableSlots: 5,
    pricing: {
      hourly: 35,
      daily: 300,
      monthly: 5500,
      currency: "₹"
    },
    allowedVehicles: ["2-wheeler", "Sedan", "SUV"],
    amenities: ["24/7 Security Guard", "Covered Roof", "Gated Security"],
    operatingHours: "07:00 AM - 11:00 PM",
    slots: [
      { id: "H-01", type: "4-Wheeler", vehicleCompatibility: ["Sedan", "SUV"], status: "AVAILABLE", basePrice: 35 },
      { id: "H-02", type: "4-Wheeler", vehicleCompatibility: ["Sedan"], status: "AVAILABLE", basePrice: 35 },
      { id: "H-03", type: "2-Wheeler", vehicleCompatibility: ["2-wheeler"], status: "AVAILABLE", basePrice: 15 },
      { id: "H-04", type: "2-Wheeler", vehicleCompatibility: ["2-wheeler"], status: "AVAILABLE", basePrice: 15 },
      { id: "H-05", type: "2-Wheeler", vehicleCompatibility: ["2-wheeler"], status: "AVAILABLE", basePrice: 15 }
    ]
  },
  {
    id: "loc-104",
    title: "Noida Sector 18 Market Multi-Level Lot",
    ownerId: "owner-04",
    ownerName: "Metro Plaza Management",
    ownerContact: "+91 98990 11223",
    rating: 4.6,
    reviewsCount: 210,
    verified: true,
    address: "Atta Market, Sector 18, Noida",
    metroDistance: "90m from Sector 18 Metro Station",
    lat: 28.5708,
    lng: 77.3261,
    image: "https://images.unsplash.com/photo-1617886322168-72b886573c35?auto=format&fit=crop&w=1000&q=80",
    type: "Commercial Underground Multi-Tier",
    totalSlots: 20,
    availableSlots: 9,
    pricing: {
      hourly: 45,
      daily: 400,
      monthly: 7000,
      currency: "₹"
    },
    allowedVehicles: ["2-wheeler", "Sedan", "SUV", "EV"],
    amenities: ["CCTV", "EV Fast Charging", "Wheelchair Accessible", "Elevator Access"],
    operatingHours: "24/7 Open",
    slots: [
      { id: "N-01", type: "EV", vehicleCompatibility: ["EV"], status: "AVAILABLE", basePrice: 50 },
      { id: "N-02", type: "4-Wheeler", vehicleCompatibility: ["Sedan", "SUV"], status: "AVAILABLE", basePrice: 45 },
      { id: "N-03", type: "4-Wheeler", vehicleCompatibility: ["Sedan"], status: "AVAILABLE", basePrice: 45 },
      { id: "N-04", type: "2-Wheeler", vehicleCompatibility: ["2-wheeler"], status: "AVAILABLE", basePrice: 20 }
    ]
  },
  {
    id: "loc-105",
    title: "Aerocity Transit Hub Luxury Bay",
    ownerId: "owner-05",
    ownerName: "Skyline Airport Hospitality",
    ownerContact: "+91 98111 22334",
    rating: 4.95,
    reviewsCount: 310,
    verified: true,
    address: "Worldmark 3, Aerocity, New Delhi",
    metroDistance: "150m from Delhi Airport Express Metro",
    lat: 28.5516,
    lng: 77.1215,
    image: "https://images.unsplash.com/photo-1545179605-1296651e9d43?auto=format&fit=crop&w=1000&q=80",
    type: "Airport Transit Secure Bay",
    totalSlots: 15,
    availableSlots: 6,
    pricing: {
      hourly: 60,
      daily: 600,
      monthly: 10000,
      currency: "₹"
    },
    allowedVehicles: ["2-wheeler", "Sedan", "SUV", "EV"],
    amenities: ["High Security", "CCTV", "EV Ultra Fast Charger", "Shuttle Service", "Valet Parking"],
    operatingHours: "24/7 Open",
    slots: [
      { id: "AIR-01", type: "EV", vehicleCompatibility: ["EV", "Sedan"], status: "AVAILABLE", basePrice: 70 },
      { id: "AIR-02", type: "SUV Heavy", vehicleCompatibility: ["SUV"], status: "AVAILABLE", basePrice: 65 },
      { id: "AIR-03", type: "4-Wheeler", vehicleCompatibility: ["Sedan"], status: "AVAILABLE", basePrice: 60 }
    ]
  }
];

export const INITIAL_BOOKINGS = [
  {
    id: "PK-9041",
    locationId: "loc-101",
    locationTitle: "Rajiv Chowk Metro Private Underground Garage",
    address: "Block B, Inner Circle, Connaught Place, New Delhi",
    slotId: "A-01",
    driverName: "Priya Sharma",
    driverPhone: "+91 98765 00112",
    vehicleNumber: "DL 01 AB 8899",
    vehicleType: "EV",
    startTime: "2026-08-07T16:00:00.000Z",
    endTime: "2026-08-07T20:00:00.000Z",
    durationHours: 4,
    totalPrice: 160,
    status: "ACTIVE",
    qrToken: "QR-PARK-8899-ACTIVE",
    checkInCode: "PK-8899",
    paymentStatus: "PAID",
    createdAt: "2026-08-07T15:30:00.000Z"
  },
  {
    id: "PK-8930",
    locationId: "loc-102",
    locationTitle: "DLF Cyber City Tech Tower Driveway",
    address: "DLF Cyber City Phase 2, Gurugram",
    slotId: "S-101",
    driverName: "Amit Kumar",
    driverPhone: "+91 99887 76655",
    vehicleNumber: "HR 26 DQ 4412",
    vehicleType: "Sedan",
    startTime: "2026-08-08T09:00:00.000Z",
    endTime: "2026-08-08T18:00:00.000Z",
    durationHours: 9,
    totalPrice: 450,
    status: "UPCOMING",
    qrToken: "QR-PARK-4412-UPCOMING",
    checkInCode: "PK-4412",
    paymentStatus: "PAID",
    createdAt: "2026-08-07T14:15:00.000Z"
  },
  {
    id: "PK-7712",
    locationId: "loc-103",
    locationTitle: "Huda City Centre Smart Residency Bay",
    address: "Sector 29 Commercial Hub, Gurugram",
    slotId: "H-02",
    driverName: "Rohan Verma",
    driverPhone: "+91 97110 33221",
    vehicleNumber: "HR 51 CC 1209",
    vehicleType: "2-wheeler",
    startTime: "2026-08-06T10:00:00.000Z",
    endTime: "2026-08-06T14:00:00.000Z",
    durationHours: 4,
    totalPrice: 60,
    status: "COMPLETED",
    qrToken: "QR-PARK-1209-COMPLETED",
    checkInCode: "PK-1209",
    paymentStatus: "PAID",
    createdAt: "2026-08-06T09:00:00.000Z"
  }
];

export const PENDING_OWNER_LISTINGS = [
  {
    id: "pend-201",
    title: "Nehru Place IT Hub Private Gated Spot",
    ownerName: "Vikram Malhotra",
    ownerContact: "+91 98119 55443",
    address: "Kalkaji Extension, near Nehru Place Metro Gate 2",
    metroDistance: "80m from Nehru Place Metro",
    type: "Private Driveway",
    totalSlots: 4,
    requestedPricing: 35,
    vehicleTypes: ["2-wheeler", "Sedan"],
    submittedDate: "2026-08-07 11:20 AM",
    status: "PENDING_VERIFICATION",
    documentsAttached: ["Ownership Deed", "Govt ID", "Slot Site Photos"]
  },
  {
    id: "pend-202",
    title: "Mg Road Metro Plaza Open Plot",
    ownerName: "Sanjay Singhania",
    ownerContact: "+91 98711 66778",
    address: "MG Road, Heritage City, Gurugram",
    metroDistance: "110m from MG Road Metro",
    type: "Gated Open Ground",
    totalSlots: 15,
    requestedPricing: 45,
    vehicleTypes: ["2-wheeler", "Sedan", "SUV"],
    submittedDate: "2026-08-07 02:45 PM",
    status: "PENDING_VERIFICATION",
    documentsAttached: ["Land Registry Certificate", "Police Clearance"]
  }
];

export const PRD_DOCUMENT_CONTENT = `# Product Requirements Document (PRD)
## Smart Parking Slot Rental & Availability Platform

### 1. Executive Summary & Product Vision
The **Smart Parking Slot Rental & Availability Platform** (ParkSpot AI) is an end-to-end location-based digital platform connecting private parking space owners (homeowners, corporate complexes, commercial building managers) with urban commuters needing instant or advance parking reservations. Focusing on high-density congestion points near Metro Stations, IT Tech Parks, and Commercial Centers, the platform transforms underutilized urban real estate into accessible, monetizable parking capacity.

---

### 2. Core Problem Statement
Urban mobility across major metros suffers severe inefficiencies:
- **Parking Search Waste**: Urban drivers spend an average of 15–20 minutes cruising for available parking, contributing up to 30% of downtown traffic congestion.
- **Underutilized Assets**: Millions of private driveways, office garages, and residential slots sit completely empty during peak business hours.
- **Informal & Opaque Systems**: Fragmented pricing, lack of real-time visibility, cash-only informal arrangements, and security ambiguity.

---

### 3. Key Target Audiences & Personas
1. **The Daily Commuter (Driver)**: Office workers, metro switch commuters seeking guaranteed, affordable spots near transit hubs.
2. **Private Parking Space Owner**: Homeowners or commercial landlords wanting passive recurring revenue from unused driveway or garage space.
3. **City Transit & Platform Administrator**: System ops monitoring urban slot density, verifying listing legitimacy, preventing fraud, and resolving billing disputes.

---

### 4. Functional Scope & Module Breakdown

#### A. Driver / Commuter Module
- **Location & Map Discovery**: Dynamic map interface with real-time slot pins, distance to transit hubs, and vehicle compatibility filters (2-wheeler, Sedan, SUV, EV).
- **Slot Reservation Engine**: Interactive layout slot picker (Slot #A1, A2, etc.), duration calculator, transparent pricing summary.
- **Digital Parking Pass & QR Check-In**: Instant generation of encrypted QR parking pass with check-in/out codes for seamless entry validation.
- **Live Status Tracking**: Countdown timers for active bookings, one-tap parking extension, and live navigation directions to slot.

#### B. Parking Space Owner Module
- **Listing Onboarding & Management**: Add space details, upload photos, set slot count, define vehicle compatibility, and specify operating hours.
- **Dynamic Pricing & Schedule Locker**: Set hourly, daily, or monthly rates; block out dates for personal use or maintenance.
- **Booking Approval Workflow**: Toggle between Instant Auto-Approve and Manual Approval mode for incoming driver requests.
- **Revenue Analytics**: Real-time earnings performance charts, slot occupancy rate, and automated payouts.

#### C. System Administrator Module
- **Verification Portal**: Review owner identity documents, land registry proof, and photo submissions before publishing listings.
- **Network Overview & Live Audit Log**: Monitor active parking sessions citywide, inspect real-time platform revenue share.
- **Dispute Resolution & Account Management**: Suspend problematic listings or resolve user refund claims.

---

### 5. Technical Architecture & Schemas

#### Core Database Schemas (MongoDB / PostgreSQL Entity Model)

\`\`\`json
// ParkingSlot Schema
{
  "_id": "ObjectId",
  "title": "String",
  "ownerId": "ObjectId (ref: User)",
  "address": "String",
  "location": {
    "type": "Point",
    "coordinates": [77.2197, 28.6328]
  },
  "metroProximity": "String",
  "allowedVehicles": ["2-wheeler", "Sedan", "SUV", "EV"],
  "pricing": {
    "hourly": 40,
    "daily": 350,
    "monthly": 6500
  },
  "amenities": ["CCTV", "EV Fast Charging", "24/7 Guard"],
  "slots": [
    { "slotCode": "A-01", "type": "EV", "status": "AVAILABLE" }
  ],
  "verifiedStatus": "APPROVED"
}
\`\`\`

---

### 6. Non-Functional Requirements (NFRs)
- **Performance**: Geo-spatial search index responses under < 1.5 seconds even with 10,000+ active slots.
- **Scalability**: Microservice-ready architecture designed to scale seamlessly across multi-city launches.
- **Security**: Strict JWT authorization, encrypted QR tokens for entry gates, HTTPS SSL communications.
- **Usability**: Responsive glassmorphism interface optimized for 3-click quick reservation on mobile devices.

---

### 7. Key Performance Indicators (KPIs)
- **Asset Utilization Rate**: % of listed slots reserved per day (Target: > 72%).
- **Commuter Time Reduction**: Average time saved searching for parking (Target: 14 mins saved per session).
- **Owner Earnings Yield**: Average monthly income per private driveway slot.
- **Booking Completion & Rating**: Target > 98% clean completion rate with > 4.7 average review score.
`;
