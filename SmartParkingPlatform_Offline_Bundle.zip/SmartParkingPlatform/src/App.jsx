import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import SearchBar from './components/DriverView/SearchBar';
import MapView from './components/DriverView/MapView';
import SlotCard from './components/DriverView/SlotCard';
import SlotDetailModal from './components/DriverView/SlotDetailModal';
import BookingModal from './components/DriverView/BookingModal';
import MyBookings from './components/DriverView/MyBookings';
import OwnerDashboard from './components/OwnerView/OwnerDashboard';
import AdminDashboard from './components/AdminView/AdminDashboard';
import TechnicalPRD from './components/PRDView/TechnicalPRD';
import Chatbot from './components/Chatbot';

import { INITIAL_PARKING_LOCATIONS, INITIAL_BOOKINGS } from './data/mockData';
import { Car, Navigation, Sparkles, AlertCircle, RefreshCw, MapPin, Clock, ArrowRight, Zap, Star, ShieldCheck, Truck } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function App() {
  const [activeRole, setActiveRole] = useState('driver');
  const [activeTab, setActiveTab] = useState('discover'); // 'discover', 'my-bookings'

  // Persistent LocalStorage
  const [locations, setLocations] = useState(() => {
    const saved = localStorage.getItem('parkspot_locations');
    return saved ? JSON.parse(saved) : INITIAL_PARKING_LOCATIONS;
  });

  const [bookings, setBookings] = useState(() => {
    const saved = localStorage.getItem('parkspot_bookings');
    return saved ? JSON.parse(saved) : INITIAL_BOOKINGS;
  });

  const [notifications, setNotifications] = useState([
    {
      id: 1,
      title: 'Active Session',
      message: 'Slot A-01 at Rajiv Chowk Metro is currently reserved & active',
      time: 'Just now'
    },
    {
      id: 2,
      title: 'New Metro Space',
      message: 'Aerocity Transit Hub Luxury Bay verified & added to map',
      time: '1 hour ago'
    }
  ]);
  const [showNotifications, setShowNotifications] = useState(false);

  // Search & Filter State
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedVehicleType, setSelectedVehicleType] = useState('ALL');
  const [maxPrice, setMaxPrice] = useState(100);
  const [requireEV, setRequireEV] = useState(false);
  const [selectedMetroHub, setSelectedMetroHub] = useState('');

  // Modals
  const [selectedLocationForModal, setSelectedLocationForModal] = useState(null);
  const [selectedLocationForBooking, setSelectedLocationForBooking] = useState(null);
  const [selectedSlotForBooking, setSelectedSlotForBooking] = useState(null);

  useEffect(() => {
    localStorage.setItem('parkspot_locations', JSON.stringify(locations));
  }, [locations]);

  useEffect(() => {
    localStorage.setItem('parkspot_bookings', JSON.stringify(bookings));
  }, [bookings]);

  // Filter Locations Logic
  const filteredLocations = locations.filter((loc) => {
    const matchesSearch =
      !searchQuery ||
      loc.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      loc.address.toLowerCase().includes(searchQuery.toLowerCase()) ||
      loc.metroDistance.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesVehicle =
      selectedVehicleType === 'ALL' ||
      loc.allowedVehicles.includes(selectedVehicleType);

    const matchesPrice = loc.pricing.hourly <= maxPrice;
    const matchesEV = !requireEV || loc.allowedVehicles.includes('EV');

    return matchesSearch && matchesVehicle && matchesPrice && matchesEV;
  });

  const handleAddNewLocation = (newLoc) => {
    setLocations([newLoc, ...locations]);
    setNotifications([
      {
        id: Date.now(),
        title: 'New Facility Published',
        message: `Your space "${newLoc.title}" is now active!`,
        time: 'Just now'
      },
      ...notifications
    ]);
  };

  const handleToggleSlotStatus = (locId, slotId) => {
    setLocations(
      locations.map((loc) => {
        if (loc.id !== locId) return loc;
        const updatedSlots = loc.slots.map((s) => {
          if (s.id !== slotId) return s;
          const nextStatus = s.status === 'AVAILABLE' ? 'BLOCKED' : 'AVAILABLE';
          return { ...s, status: nextStatus };
        });
        const freeCount = updatedSlots.filter((s) => s.status === 'AVAILABLE').length;
        return { ...loc, slots: updatedSlots, availableSlots: freeCount };
      })
    );
  };

  const handleConfirmBooking = (newBooking) => {
    setBookings([newBooking, ...bookings]);

    setLocations(
      locations.map((loc) => {
        if (loc.id !== newBooking.locationId) return loc;
        const updatedSlots = loc.slots.map((s) => {
          if (s.id !== newBooking.slotId) return s;
          return { ...s, status: 'OCCUPIED' };
        });
        const freeCount = updatedSlots.filter((s) => s.status === 'AVAILABLE').length;
        return { ...loc, slots: updatedSlots, availableSlots: freeCount };
      })
    );

    setNotifications([
      {
        id: Date.now(),
        title: 'Booking Confirmed!',
        message: `Pass ${newBooking.id} generated for Bay ${newBooking.slotId}`,
        time: 'Just now'
      },
      ...notifications
    ]);
  };

  const handleExtendBooking = (bookingId) => {
    setBookings(
      bookings.map((b) => {
        if (b.id !== bookingId) return b;
        return {
          ...b,
          durationHours: b.durationHours + 1,
          totalPrice: b.totalPrice + 40,
          endTime: new Date(new Date(b.endTime).getTime() + 3600 * 1000).toISOString()
        };
      })
    );
    alert('Booking extended by +1 Hour!');
  };

  const handleCancelBooking = (bookingId) => {
    if (!window.confirm('Are you sure you want to cancel this parking reservation?')) return;
    setBookings(
      bookings.map((b) => {
        if (b.id !== bookingId) return b;
        return { ...b, status: 'CANCELLED' };
      })
    );
  };

  const activeBookingsCount = bookings.filter((b) => b.status === 'ACTIVE').length;

  return (
    <div className="min-h-screen bg-[#f8fafc] dark:bg-[#030712] text-slate-900 dark:text-white flex flex-col font-main selection:bg-indigo-600 selection:text-white transition-colors duration-500">
      {/* Top Header Bar */}
      <Header
        activeRole={activeRole}
        setActiveRole={setActiveRole}
        activeBookingsCount={activeBookingsCount}
        notifications={notifications}
        showNotifications={showNotifications}
        setShowNotifications={setShowNotifications}
      />

      {/* Main App Container */}
      <main className="flex-1 w-full mx-auto pb-24">
        {/* DRIVER MODE */}
        {activeRole === 'driver' && (
          <div>
            {/* Electric Indigo 3D Hero Banner */}
            <section className="relative pt-12 pb-16 overflow-hidden">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
                  <motion.div
                    initial={{ opacity: 0, x: -40 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.8, ease: "easeOut" }}
                    className="lg:col-span-7 space-y-6"
                  >
                    <div className="inline-flex items-center space-x-2 bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border border-indigo-500/20 px-4 py-2 rounded-full font-black text-xs uppercase tracking-wider">
                      <Zap className="h-4 w-4 text-emerald-500 fill-emerald-500" />
                      <span>Next-Gen Smart Parking Engine</span>
                    </div>

                    <h1 className="text-5xl sm:text-6xl lg:text-7xl font-black text-slate-900 dark:text-white leading-[1.08] tracking-tight font-display">
                      Park Smarter. <br />
                      <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 via-purple-600 to-emerald-400 text-glow">
                        Reserve Instantly.
                      </span>
                    </h1>

                    <p className="text-lg sm:text-xl text-slate-600 dark:text-slate-400 font-medium leading-relaxed max-w-xl">
                      Locate and reserve verified private parking bays near metro stations & business hubs in seconds. Zero cruising, guaranteed availability.
                    </p>

                    <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4 pt-4">
                      <button
                        onClick={() => setActiveTab('discover')}
                        className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-8 py-4 rounded-2xl font-black text-base transition-all hover:scale-105 active:scale-95 shadow-xl shadow-indigo-500/25 flex items-center justify-center space-x-2 cursor-pointer"
                      >
                        <span>Find Parking Bays</span>
                        <ArrowRight className="h-5 w-5" />
                      </button>

                      <button
                        onClick={() => setActiveRole('owner')}
                        className="bg-white dark:bg-slate-900 text-slate-900 dark:text-white px-8 py-4 rounded-2xl font-black text-base transition-all hover:bg-indigo-50 dark:hover:bg-slate-800 border border-indigo-100 dark:border-slate-800 flex items-center justify-center cursor-pointer shadow-sm"
                      >
                        <span>Host Your Driveway</span>
                      </button>
                    </div>

                    {/* Trust Indicators */}
                    <div className="pt-6 flex items-center space-x-6">
                      <div className="flex -space-x-3">
                        {[1, 2, 3, 4].map((i) => (
                          <img
                            key={i}
                            src={`https://i.pravatar.cc/100?img=${i + 15}`}
                            className="h-10 w-10 rounded-full border-2 border-white dark:border-slate-900 object-cover shadow-sm"
                            alt=""
                          />
                        ))}
                      </div>
                      <div>
                        <div className="flex text-amber-400">
                          {[1, 2, 3, 4, 5].map((i) => (
                            <Star key={i} className="h-4 w-4 fill-current" />
                          ))}
                        </div>
                        <p className="text-xs font-black text-slate-900 dark:text-slate-300 mt-1 uppercase tracking-wider">
                          Trusted by 5,000+ happy commuters
                        </p>
                      </div>
                    </div>
                  </motion.div>

                  {/* 3D Floating Hero Showcase Card */}
                  <motion.div
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.8, delay: 0.2 }}
                    className="lg:col-span-5 relative perspective-1000 hidden lg:block"
                  >
                    <div className="relative z-10 bg-white dark:bg-slate-900 p-6 rounded-[40px] shadow-2xl border border-indigo-100/60 dark:border-slate-800 transform-style-3d">
                      <img
                        src="https://images.unsplash.com/photo-1506521781263-d8422e82f27a?auto=format&fit=crop&q=80&w=1000"
                        alt="Smart Parking Bay"
                        className="rounded-[32px] w-full h-72 object-cover"
                      />

                      {/* Floating Badge 1 */}
                      <motion.div
                        animate={{ y: [0, -12, 0] }}
                        transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                        className="absolute -top-6 -right-6 bg-white dark:bg-slate-800 p-5 rounded-3xl shadow-2xl border border-indigo-100 dark:border-slate-700"
                      >
                        <div className="bg-emerald-500/10 p-2.5 rounded-2xl inline-block mb-2">
                          <Zap className="h-5 w-5 text-emerald-500 fill-current" />
                        </div>
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                          EV Charger Ready
                        </p>
                        <p className="text-sm font-black text-slate-900 dark:text-white">Rajiv Chowk Metro</p>
                      </motion.div>

                      {/* Floating Badge 2 */}
                      <motion.div
                        animate={{ y: [0, 12, 0] }}
                        transition={{ duration: 5, repeat: Infinity, ease: "easeInOut", delay: 1 }}
                        className="absolute -bottom-6 -left-6 bg-white dark:bg-slate-800 p-5 rounded-3xl shadow-2xl border border-indigo-100 dark:border-slate-700"
                      >
                        <div className="bg-indigo-500/10 p-2.5 rounded-2xl inline-block mb-2">
                          <Car className="h-5 w-5 text-indigo-500" />
                        </div>
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                          Instant Gate QR
                        </p>
                        <p className="text-sm font-black text-slate-900 dark:text-white">Cyber City Bay #A-02</p>
                      </motion.div>
                    </div>
                  </motion.div>
                </div>
              </div>
            </section>

            {/* Sub Nav Bar (Discover vs My Reservations) */}
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-6">
              <div className="bg-white dark:bg-slate-900 p-3 rounded-3xl shadow-xl border border-indigo-100/60 dark:border-slate-800 flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => setActiveTab('discover')}
                    className={`px-6 py-3 rounded-2xl text-xs font-black transition-all cursor-pointer ${
                      activeTab === 'discover'
                        ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-md'
                        : 'text-slate-600 dark:text-slate-400 hover:bg-indigo-50 dark:hover:bg-slate-800'
                    }`}
                  >
                    🔍 Discover Parking Bays ({filteredLocations.length})
                  </button>
                  <button
                    onClick={() => setActiveTab('my-bookings')}
                    className={`px-6 py-3 rounded-2xl text-xs font-black transition-all flex items-center space-x-2 cursor-pointer ${
                      activeTab === 'my-bookings'
                        ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-md'
                        : 'text-slate-600 dark:text-slate-400 hover:bg-indigo-50 dark:hover:bg-slate-800'
                    }`}
                  >
                    <Car className="h-4 w-4" />
                    <span>My Reservations</span>
                    {activeBookingsCount > 0 && (
                      <span className="px-2 py-0.5 rounded-full bg-emerald-500 text-white font-black text-[10px]">
                        {activeBookingsCount}
                      </span>
                    )}
                  </button>
                </div>

                <div className="hidden sm:flex items-center space-x-2 text-xs text-slate-500 dark:text-slate-400 font-bold">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping"></span>
                  <span>Live Metro GPS Active</span>
                </div>
              </div>
            </div>

            {/* Discover Split View Container */}
            {activeTab === 'discover' && (
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex flex-col lg:flex-row gap-8">
                  {/* Left Column: Search & Cards */}
                  <div className="w-full lg:w-7/12 space-y-6">
                    <SearchBar
                      searchQuery={searchQuery}
                      setSearchQuery={setSearchQuery}
                      selectedVehicleType={selectedVehicleType}
                      setSelectedVehicleType={setSelectedVehicleType}
                      maxPrice={maxPrice}
                      setMaxPrice={setMaxPrice}
                      requireEV={requireEV}
                      setRequireEV={setRequireEV}
                      selectedMetroHub={selectedMetroHub}
                      setSelectedMetroHub={setSelectedMetroHub}
                    />

                    {/* Results Cards Grid */}
                    {filteredLocations.length === 0 ? (
                      <div className="bg-white dark:bg-slate-900 p-12 text-center rounded-[40px] border border-indigo-100/60 dark:border-slate-800 shadow-xl space-y-3">
                        <AlertCircle className="h-12 w-12 text-amber-500 mx-auto" />
                        <h3 className="text-2xl font-black text-slate-900 dark:text-white">No Parking Spaces Found</h3>
                        <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                          Try adjusting your search criteria or price slider.
                        </p>
                        <button
                          onClick={() => {
                            setSearchQuery('');
                            setSelectedVehicleType('ALL');
                            setMaxPrice(100);
                            setRequireEV(false);
                          }}
                          className="bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 px-6 py-3 rounded-2xl text-xs font-black hover:bg-indigo-600 hover:text-white transition-all inline-flex items-center space-x-2 mt-4 cursor-pointer"
                        >
                          <RefreshCw className="h-4 w-4" /> Reset Filters
                        </button>
                      </div>
                    ) : (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                        {filteredLocations.map((loc) => (
                          <SlotCard
                            key={loc.id}
                            location={loc}
                            onSelectLocation={(l) => setSelectedLocationForModal(l)}
                          />
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Right Column: Sticky Leaflet Map */}
                  <div className="w-full lg:w-5/12 h-[500px] lg:h-[calc(100vh-180px)] lg:sticky lg:top-28">
                    <MapView
                      locations={filteredLocations}
                      onSelectLocation={(l) => setSelectedLocationForModal(l)}
                    />
                  </div>
                </div>
              </div>
            )}

            {/* My Reservations View */}
            {activeTab === 'my-bookings' && (
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <MyBookings
                  bookings={bookings}
                  onExtendBooking={handleExtendBooking}
                  onCancelBooking={handleCancelBooking}
                  onViewPass={(booking) => {
                    const matchedLoc = locations.find((l) => l.id === booking.locationId) || locations[0];
                    setSelectedLocationForBooking(matchedLoc);
                    setSelectedSlotForBooking({ id: booking.slotId, type: booking.vehicleType, basePrice: 40 });
                  }}
                />
              </div>
            )}
          </div>
        )}

        {/* OWNER MODE */}
        {activeRole === 'owner' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8">
            <OwnerDashboard
              locations={locations}
              onAddNewLocation={handleAddNewLocation}
              onToggleSlotStatus={handleToggleSlotStatus}
            />
          </div>
        )}

        {/* ADMIN MODE */}
        {activeRole === 'admin' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8">
            <AdminDashboard
              locations={locations}
              setLocations={setLocations}
            />
          </div>
        )}

        {/* PRD MODE */}
        {activeRole === 'prd' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8">
            <TechnicalPRD />
          </div>
        )}
      </main>

      {/* Floating RentEase Style AI Chatbot Assistant */}
      <Chatbot />

      {/* Modals */}
      <AnimatePresence>
        {selectedLocationForModal && (
          <SlotDetailModal
            location={selectedLocationForModal}
            onClose={() => setSelectedLocationForModal(null)}
            onProceedToBooking={(loc, slot) => {
              setSelectedLocationForModal(null);
              setSelectedLocationForBooking(loc);
              setSelectedSlotForBooking(slot);
            }}
          />
        )}

        {selectedLocationForBooking && selectedSlotForBooking && (
          <BookingModal
            location={selectedLocationForBooking}
            slot={selectedSlotForBooking}
            onClose={() => {
              setSelectedLocationForBooking(null);
              setSelectedSlotForBooking(null);
            }}
            onConfirmBooking={handleConfirmBooking}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
