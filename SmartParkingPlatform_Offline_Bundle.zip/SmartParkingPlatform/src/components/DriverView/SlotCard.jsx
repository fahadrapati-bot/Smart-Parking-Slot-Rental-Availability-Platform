import React from 'react';
import { Star, ShieldCheck, MapPin, Navigation, Zap, ArrowRight } from 'lucide-react';
import { motion } from 'framer-motion';

export default function SlotCard({ location, onSelectLocation }) {
  return (
    <motion.div
      whileHover={{ y: -10 }}
      transition={{ duration: 0.3 }}
      onClick={() => onSelectLocation(location)}
      className="group bg-white dark:bg-slate-900 rounded-[36px] overflow-hidden shadow-sm hover:shadow-2xl hover:shadow-indigo-500/10 transition-all border border-indigo-100/60 dark:border-slate-800 flex flex-col h-full relative cursor-pointer"
    >
      <div className="flex flex-col h-full">
        {/* Photo Container */}
        <div className="relative h-52 overflow-hidden">
          <img
            src={location.image}
            alt={location.title}
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
          />
          <div className="absolute inset-0 bg-slate-950/20 opacity-0 group-hover:opacity-100 transition-opacity"></div>

          {/* Verification Badge */}
          {location.verified && (
            <div className="absolute top-4 left-4 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md px-3.5 py-1.5 rounded-2xl text-[10px] font-black text-indigo-600 dark:text-indigo-400 uppercase tracking-widest shadow-lg flex items-center space-x-1.5 border border-indigo-100 dark:border-slate-800">
              <ShieldCheck className="h-3.5 w-3.5 text-indigo-600 dark:text-indigo-400" />
              <span>Verified Host</span>
            </div>
          )}

          {/* Rating */}
          <div className="absolute top-4 right-4 bg-slate-950/80 backdrop-blur-md px-3 py-1.5 rounded-2xl text-xs font-bold text-white flex items-center shadow-lg">
            <Star className="h-3.5 w-3.5 text-amber-400 fill-current mr-1" />
            <span>{location.rating}</span>
          </div>

          {/* Metro Proximity Tag */}
          <div className="absolute bottom-4 left-4 right-4">
            <div className="bg-slate-950/70 backdrop-blur-md px-3 py-1.5 rounded-xl text-xs font-bold text-indigo-200 inline-flex items-center space-x-1">
              <Navigation className="h-3.5 w-3.5 text-emerald-400" />
              <span>{location.metroDistance}</span>
            </div>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-6 flex flex-col flex-grow space-y-3">
          <h3 className="text-xl font-black text-slate-900 dark:text-white group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors line-clamp-1">
            {location.title}
          </h3>

          <p className="text-slate-500 dark:text-slate-400 text-xs font-medium line-clamp-1 flex items-center space-x-1">
            <MapPin className="h-3.5 w-3.5 text-slate-400 shrink-0" />
            <span>{location.address}</span>
          </p>

          {/* Allowed Vehicles */}
          <div className="flex flex-wrap gap-1.5 pt-1">
            {location.allowedVehicles.map((v) => (
              <span
                key={v}
                className="px-2.5 py-1 rounded-xl bg-indigo-50/50 dark:bg-slate-800/80 text-[10px] font-bold text-slate-600 dark:text-slate-300 flex items-center space-x-1 border border-indigo-100/50 dark:border-slate-700/50"
              >
                {v === 'EV' && <Zap className="h-3 w-3 text-emerald-500 fill-emerald-500" />}
                {v === '2-wheeler' && '🛵'}
                {v === 'Sedan' && '🚘'}
                {v === 'SUV' && '🚙'}
                <span>{v}</span>
              </span>
            ))}
          </div>

          {/* Slots Availability */}
          <div className="flex justify-between items-center text-xs font-bold pt-1">
            <span className="text-slate-400 uppercase tracking-widest text-[10px]">Open Bays</span>
            <span className={location.availableSlots > 2 ? 'text-emerald-500 font-black' : 'text-amber-500 font-black'}>
              {location.availableSlots} of {location.totalSlots} available
            </span>
          </div>

          {/* Footer Price & Action */}
          <div className="mt-auto flex items-center justify-between pt-4 border-t border-indigo-50 dark:border-slate-800">
            <div>
              <span className="text-[10px] text-slate-400 dark:text-slate-500 block uppercase font-black tracking-widest">
                Rate Per Hour
              </span>
              <div className="flex items-baseline text-2xl font-black text-emerald-500 font-mono">
                {location.pricing.currency}{location.pricing.hourly}
                <span className="text-xs text-slate-400 font-normal font-sans ml-1">/hr</span>
              </div>
            </div>
            <div className="bg-gradient-to-br from-indigo-600 to-purple-600 text-white h-12 w-12 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-all shadow-md shadow-indigo-500/20">
              <ArrowRight className="h-5 w-5" />
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
