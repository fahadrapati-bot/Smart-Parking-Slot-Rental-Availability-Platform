import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { X, CheckCircle2, Car, Calendar, Clock, CreditCard, ShieldCheck, Zap, QrCode, Download, Printer, ArrowRight, ArrowLeft, Sparkles } from 'lucide-react';
import { motion } from 'framer-motion';

export default function BookingModal({ location, slot, onClose, onConfirmBooking }) {
  const [step, setStep] = useState(1);
  const [vehicleNumber, setVehicleNumber] = useState('DL 01 AB 7788');
  const [vehicleType, setVehicleType] = useState('Sedan');
  const [durationHours, setDurationHours] = useState(4);
  const [selectedAddons, setSelectedAddons] = useState([]);
  const [confirmedBooking, setConfirmedBooking] = useState(null);

  const basePrice = slot?.basePrice || location.pricing.hourly;
  const addonsTotal = selectedAddons.reduce((acc, curr) => acc + curr.price, 0);
  const totalPrice = basePrice * durationHours + addonsTotal;

  const ADDONS_LIST = [
    { id: 'ev-charge', title: 'EV Supercharger Session', price: 120, icon: '⚡' },
    { id: 'valet', title: 'Priority Valet Assistance', price: 50, icon: '🔑' },
    { id: 'wash', title: 'Express Exterior Carwash', price: 150, icon: '🚿' }
  ];

  const toggleAddon = (addon) => {
    if (selectedAddons.find((a) => a.id === addon.id)) {
      setSelectedAddons(selectedAddons.filter((a) => a.id !== addon.id));
    } else {
      setSelectedAddons([...selectedAddons, addon]);
    }
  };

  const handleFinalSubmit = () => {
    const bookingCode = `PK-${Math.floor(1000 + Math.random() * 9000)}`;
    const newBooking = {
      id: bookingCode,
      locationId: location.id,
      locationTitle: location.title,
      address: location.address,
      slotId: slot.id,
      driverName: 'Priya Sharma',
      driverPhone: '+91 98765 43210',
      vehicleNumber: vehicleNumber.toUpperCase(),
      vehicleType,
      startTime: new Date().toISOString(),
      endTime: new Date(Date.now() + durationHours * 3600 * 1000).toISOString(),
      durationHours,
      totalPrice,
      status: 'ACTIVE',
      qrToken: `QR-PARK-${bookingCode}`,
      checkInCode: bookingCode,
      paymentStatus: 'PAID',
      createdAt: new Date().toISOString()
    };

    setConfirmedBooking(newBooking);
    setStep(3);
    onConfirmBooking(newBooking);

    try {
      confetti({
        particleCount: 120,
        spread: 80,
        origin: { y: 0.6 }
      });
    } catch (e) {
      console.log('Confetti triggered');
    }
  };

  return (
    <div
      className="fixed inset-0 bg-slate-950/70 backdrop-blur-md z-[200] flex items-center justify-center p-4 overflow-y-auto"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.9, opacity: 0, y: 20 }}
        onClick={(e) => e.stopPropagation()}
        className="bg-white dark:bg-slate-900 w-full max-w-xl rounded-[40px] overflow-hidden shadow-2xl relative my-8 border border-indigo-100/60 dark:border-slate-800 transition-colors duration-500"
      >
        {/* Header */}
        <div className="p-6 bg-indigo-50/50 dark:bg-slate-800/60 border-b border-indigo-100/60 dark:border-slate-800 flex items-center justify-between">
          <div>
            <span className="text-[10px] font-black text-indigo-600 dark:text-indigo-400 uppercase tracking-widest block font-mono">
              Step {step} of 3
            </span>
            <h3 className="text-xl font-black text-slate-900 dark:text-white font-display">
              {step === 1 && 'Reserve Parking Slot'}
              {step === 2 && 'Enhance Your Session (Optional)'}
              {step === 3 && '🎉 Official Digital Gate Pass'}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-3 bg-white dark:bg-slate-800 hover:bg-indigo-50 dark:hover:bg-slate-700 rounded-full transition-colors cursor-pointer text-slate-900 dark:text-white border border-indigo-100/50 dark:border-slate-700"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Step 1 */}
        {step === 1 && (
          <div className="p-8 space-y-6">
            <div className="bg-indigo-500/10 border border-indigo-500/20 p-5 rounded-3xl flex items-center justify-between">
              <div>
                <p className="text-xs text-indigo-600 dark:text-indigo-400 font-black">{location.title}</p>
                <p className="text-lg font-black text-slate-900 dark:text-white mt-0.5">
                  Selected Bay: Slot #{slot.id}
                </p>
              </div>
              <span className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white text-xs font-black px-3.5 py-1.5 rounded-xl uppercase tracking-wider">
                {slot.type} Bay
              </span>
            </div>

            <div>
              <label className="block text-xs font-black text-slate-400 dark:text-slate-500 mb-2 uppercase tracking-widest flex items-center space-x-2">
                <Car className="h-4 w-4 text-indigo-500" />
                <span>Vehicle Plate Number</span>
              </label>
              <input
                type="text"
                value={vehicleNumber}
                onChange={(e) => setVehicleNumber(e.target.value)}
                placeholder="e.g. DL 01 AB 1234"
                className="w-full font-mono uppercase font-black text-xl text-center tracking-widest text-slate-900 dark:text-white bg-indigo-50/40 dark:bg-slate-800/80 py-4 rounded-2xl border-none outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-black text-slate-400 dark:text-slate-500 mb-2 uppercase tracking-widest flex items-center space-x-2">
                <Clock className="h-4 w-4 text-indigo-500" />
                <span>Select Duration (Hours)</span>
              </label>
              <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
                {[1, 2, 4, 8, 12, 24].map((hrs) => (
                  <button
                    key={hrs}
                    type="button"
                    onClick={() => setDurationHours(hrs)}
                    className={`py-3 rounded-2xl font-black text-xs transition-all cursor-pointer ${
                      durationHours === hrs
                        ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-lg shadow-indigo-500/25'
                        : 'bg-indigo-50/40 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-indigo-50'
                    }`}
                  >
                    {hrs}h
                  </button>
                ))}
              </div>
            </div>

            <div className="bg-indigo-50/40 dark:bg-slate-800/60 p-5 rounded-3xl space-y-2 text-xs">
              <div className="flex justify-between text-slate-500 dark:text-slate-400 font-medium">
                <span>Base Rate (₹{basePrice}/hr × {durationHours} hrs)</span>
                <span className="text-slate-900 dark:text-white font-black font-mono">₹{basePrice * durationHours}</span>
              </div>
              <div className="flex justify-between text-slate-500 dark:text-slate-400 font-medium">
                <span>Service Fee & Security</span>
                <span className="text-emerald-500 font-black">FREE</span>
              </div>
              <div className="pt-3 border-t border-indigo-100 dark:border-slate-700 flex justify-between text-sm font-black">
                <span className="text-slate-900 dark:text-white">Total Amount</span>
                <span className="text-emerald-500 text-xl font-mono">₹{basePrice * durationHours}</span>
              </div>
            </div>

            <button
              onClick={() => setStep(2)}
              className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 text-white py-4 rounded-2xl font-black text-base hover:opacity-90 transition-all flex items-center justify-center space-x-2 cursor-pointer shadow-xl shadow-indigo-500/25"
            >
              <span>Next: Add-ons & Review</span>
              <ArrowRight className="h-5 w-5" />
            </button>
          </div>
        )}

        {/* Step 2 */}
        {step === 2 && (
          <div className="p-8 space-y-6">
            <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
              Select optional services to enhance your parking session:
            </p>

            <div className="space-y-3">
              {ADDONS_LIST.map((addon) => {
                const isSelected = selectedAddons.some((a) => a.id === addon.id);
                return (
                  <div
                    key={addon.id}
                    onClick={() => toggleAddon(addon)}
                    className={`p-5 rounded-3xl cursor-pointer flex items-center justify-between transition-all border ${
                      isSelected
                        ? 'bg-indigo-500/10 border-indigo-500 text-slate-900 dark:text-white shadow-lg'
                        : 'bg-indigo-50/30 dark:bg-slate-800/80 border-indigo-100/50 dark:border-slate-700/50 text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    <div className="flex items-center space-x-4">
                      <span className="text-2xl">{addon.icon}</span>
                      <div>
                        <p className="text-sm font-black text-slate-900 dark:text-white">{addon.title}</p>
                        <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">+₹{addon.price} flat rate</p>
                      </div>
                    </div>
                    <div
                      className={`w-6 h-6 rounded-xl border flex items-center justify-center ${
                        isSelected ? 'bg-indigo-600 border-indigo-600 text-white' : 'border-slate-300 dark:border-slate-600'
                      }`}
                    >
                      {isSelected && <CheckCircle2 className="h-4 w-4" />}
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="bg-indigo-50/40 dark:bg-slate-800/60 p-5 rounded-3xl space-y-2 text-xs">
              <div className="flex justify-between text-slate-500 dark:text-slate-400">
                <span>Parking Slot Base Rate</span>
                <span className="text-slate-900 dark:text-white font-black font-mono">₹{basePrice * durationHours}</span>
              </div>
              {selectedAddons.map((a) => (
                <div key={a.id} className="flex justify-between text-indigo-600 dark:text-indigo-400 font-bold">
                  <span>+ {a.title}</span>
                  <span className="font-mono">₹{a.price}</span>
                </div>
              ))}
              <div className="pt-3 border-t border-indigo-100 dark:border-slate-700 flex justify-between text-base font-black">
                <span className="text-slate-900 dark:text-white">Total Payable</span>
                <span className="text-emerald-500 text-2xl font-mono">₹{totalPrice}</span>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <button
                onClick={() => setStep(1)}
                className="bg-indigo-50/60 dark:bg-slate-800 text-slate-700 dark:text-slate-300 px-6 py-4 rounded-2xl font-black text-sm hover:bg-indigo-100 dark:hover:bg-slate-700 transition-all flex items-center space-x-2 cursor-pointer"
              >
                <ArrowLeft className="h-5 w-5" />
                <span>Back</span>
              </button>
              <button
                onClick={handleFinalSubmit}
                className="flex-1 bg-gradient-to-r from-indigo-600 to-purple-600 text-white py-4 rounded-2xl font-black text-base hover:opacity-90 transition-all flex items-center justify-center space-x-2 cursor-pointer shadow-xl shadow-indigo-500/25"
              >
                <ShieldCheck className="h-5 w-5" />
                <span>Pay & Confirm ₹{totalPrice}</span>
              </button>
            </div>
          </div>
        )}

        {/* Step 3: Ticket Pass */}
        {step === 3 && confirmedBooking && (
          <div className="p-8 space-y-6 text-center">
            <div className="bg-white dark:bg-slate-800 border-2 border-dashed border-indigo-500 p-6 rounded-3xl space-y-4 text-left shadow-2xl relative overflow-hidden">
              <div className="flex justify-between items-start border-b border-indigo-50 dark:border-slate-700 pb-4">
                <div>
                  <span className="bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 px-3 py-1 rounded-xl text-[10px] font-black uppercase tracking-widest inline-block mb-1">
                    <Sparkles className="h-3 w-3 inline mr-1 text-emerald-400" /> DIGITAL GATE PASS
                  </span>
                  <h4 className="font-black text-xl text-slate-900 dark:text-white font-display">ParkSpot AI Gate Pass</h4>
                  <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">{confirmedBooking.locationTitle}</p>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-slate-400 font-mono block font-black">PASS ID</span>
                  <span className="font-mono text-base font-black text-emerald-500">{confirmedBooking.id}</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 text-xs">
                <div className="bg-indigo-50/40 dark:bg-slate-900/60 p-3.5 rounded-2xl">
                  <span className="text-slate-400 text-[10px] block font-black uppercase tracking-widest">RESERVED BAY</span>
                  <span className="font-black text-slate-900 dark:text-white text-lg font-mono">Slot #{confirmedBooking.slotId}</span>
                </div>
                <div className="bg-indigo-50/40 dark:bg-slate-900/60 p-3.5 rounded-2xl">
                  <span className="text-slate-400 text-[10px] block font-black uppercase tracking-widest">VEHICLE PLATE</span>
                  <span className="font-black text-indigo-600 dark:text-indigo-400 text-base font-mono">{confirmedBooking.vehicleNumber}</span>
                </div>
              </div>

              <div className="flex flex-col items-center justify-center p-6 bg-slate-950 text-white rounded-2xl space-y-2">
                <div className="w-36 h-36 bg-white p-2 rounded-xl flex items-center justify-center">
                  <QrCode className="h-32 w-32 text-slate-900" />
                </div>
                <p className="text-xs font-black tracking-widest font-mono text-emerald-400">
                  CODE: {confirmedBooking.checkInCode}
                </p>
                <p className="text-[10px] text-slate-400">Scan at automated gate barrier</p>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <button
                onClick={() => window.print()}
                className="flex-1 bg-indigo-50/60 dark:bg-slate-800 text-slate-900 dark:text-white py-4 rounded-2xl font-black text-sm hover:bg-indigo-100 dark:hover:bg-slate-700 transition-all flex items-center justify-center space-x-2 cursor-pointer"
              >
                <Printer className="h-5 w-5" />
                <span>Print Ticket</span>
              </button>
              <button
                onClick={onClose}
                className="flex-1 bg-gradient-to-r from-indigo-600 to-purple-600 text-white py-4 rounded-2xl font-black text-sm hover:opacity-90 transition-all cursor-pointer shadow-xl shadow-indigo-500/25"
              >
                View Reservations
              </button>
            </div>
          </div>
        )}
      </motion.div>
    </div>
  );
}
