import React from 'react';
import { Search, MapPin, Car, Zap, SlidersHorizontal, Filter, Sparkles } from 'lucide-react';
import { motion } from 'framer-motion';

export default function SearchBar({
  searchQuery,
  setSearchQuery,
  selectedVehicleType,
  setSelectedVehicleType,
  maxPrice,
  setMaxPrice,
  requireEV,
  setRequireEV,
  selectedMetroHub,
  setSelectedMetroHub
}) {
  const METRO_HUBS = [
    { name: '📍 All Locations', query: '' },
    { name: '🚇 Rajiv Chowk Metro', query: 'Rajiv Chowk' },
    { name: '🏢 Cyber City Rapid', query: 'Cyber City' },
    { name: '🚉 Huda City Centre', query: 'Huda City' },
    { name: '🛍️ Sector 18 Noida', query: 'Sector 18' },
    { name: '✈️ Aerocity Hub', query: 'Aerocity' }
  ];

  return (
    <div className="bg-white dark:bg-slate-900 p-6 rounded-[32px] shadow-xl border border-indigo-100/60 dark:border-slate-800 mb-6 transition-colors duration-500">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-center">
        {/* Search Input */}
        <div className="lg:col-span-4 relative">
          <Search className="absolute left-5 top-1/2 -translate-y-1/2 h-5 w-5 text-indigo-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search parking destination..."
            className="w-full pl-13 pr-6 py-4 rounded-2xl bg-indigo-50/50 dark:bg-slate-800/80 border-none text-slate-900 dark:text-white placeholder-slate-400 font-bold text-sm focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
          />
        </div>

        {/* Vehicle Select */}
        <div className="lg:col-span-3">
          <select
            value={selectedVehicleType}
            onChange={(e) => setSelectedVehicleType(e.target.value)}
            className="w-full px-5 py-4 rounded-2xl bg-indigo-50/50 dark:bg-slate-800/80 border-none outline-none focus:ring-2 focus:ring-indigo-500 font-black text-slate-700 dark:text-slate-200 text-xs cursor-pointer appearance-none"
          >
            <option value="ALL" className="bg-white dark:bg-slate-900">🚗 All Vehicle Compatibility</option>
            <option value="2-wheeler" className="bg-white dark:bg-slate-900">🛵 2-Wheeler (Motorcycle/Scooter)</option>
            <option value="Sedan" className="bg-white dark:bg-slate-900">🚘 Sedan / Hatchback</option>
            <option value="SUV" className="bg-white dark:bg-slate-900">🚙 SUV / Heavy Bay</option>
            <option value="EV" className="bg-white dark:bg-slate-900">⚡ Electric Vehicle (EV Bay)</option>
          </select>
        </div>

        {/* Price Slider */}
        <div className="lg:col-span-3 bg-indigo-50/50 dark:bg-slate-800/80 p-3.5 rounded-2xl border border-indigo-100/50 dark:border-slate-700/50">
          <div className="flex justify-between items-center mb-1.5">
            <span className="text-[10px] font-black text-slate-400 dark:text-slate-400 uppercase tracking-widest flex items-center gap-1">
              <SlidersHorizontal className="h-3 w-3 text-indigo-500" /> Max Hourly Rate
            </span>
            <span className="text-sm font-black text-emerald-500 font-mono">₹{maxPrice}/hr</span>
          </div>
          <input
            type="range"
            min="20"
            max="100"
            step="5"
            value={maxPrice}
            onChange={(e) => setMaxPrice(Number(e.target.value))}
            className="w-full accent-indigo-600 cursor-pointer h-2 bg-indigo-100 dark:bg-slate-700 rounded-lg"
          />
        </div>

        {/* EV Toggle */}
        <div className="lg:col-span-2">
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={() => setRequireEV(!requireEV)}
            className={`w-full py-4 px-4 rounded-2xl text-xs font-black transition-all flex items-center justify-center space-x-2 cursor-pointer ${
              requireEV
                ? 'bg-emerald-500 text-white shadow-lg shadow-emerald-500/25'
                : 'bg-indigo-50/50 dark:bg-slate-800/80 text-slate-600 dark:text-slate-300 hover:bg-indigo-100 dark:hover:bg-slate-700'
            }`}
          >
            <Zap className={`h-4 w-4 ${requireEV ? 'fill-current' : 'text-emerald-500'}`} />
            <span>{requireEV ? 'EV Active' : 'EV Charger'}</span>
          </motion.button>
        </div>
      </div>

      {/* Transit Quick Pills */}
      <div className="mt-4 pt-4 border-t border-indigo-50 dark:border-slate-800 flex items-center gap-2 overflow-x-auto scrollbar-none">
        <span className="text-[10px] font-black text-indigo-400 dark:text-indigo-500 uppercase tracking-widest shrink-0">
          Metro Hubs:
        </span>
        {METRO_HUBS.map((hub) => (
          <button
            key={hub.name}
            onClick={() => {
              setSelectedMetroHub(hub.query);
              setSearchQuery(hub.query);
            }}
            className={`px-4 py-2 rounded-full text-xs font-black transition-all shrink-0 cursor-pointer ${
              selectedMetroHub === hub.query
                ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-md'
                : 'bg-indigo-50/60 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-indigo-100 dark:hover:bg-slate-700'
            }`}
          >
            {hub.name}
          </button>
        ))}
      </div>
    </div>
  );
}
