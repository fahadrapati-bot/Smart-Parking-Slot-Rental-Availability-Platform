import React, { useState } from 'react';
import { X, Star, ShieldCheck, MapPin, Navigation, Car, Zap, Clock, User, CheckCircle, ArrowRight } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function SlotDetailModal({ location, onClose, onProceedToBooking }) {
  const [selectedSlotId, setSelectedSlotId] = useState(
    location.slots.find((s) => s.status === 'AVAILABLE')?.id || location.slots[0]?.id
  );

  const selectedSlot = location.slots.find((s) => s.id === selectedSlotId);

  return (
    <div
      className="fixed inset-0 bg-slate-950/70 backdrop-blur-md z-[200] flex items-center justify-center p-4 overflow-y-auto"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.9, opacity: 0, y: 20 }}
        onClick={(e) => e.stopPropagation()}
        className="bg-white dark:bg-slate-900 w-full max-w-4xl rounded-[40px] overflow-hidden shadow-2xl relative my-8 border border-indigo-100/60 dark:border-slate-800 transition-colors duration-500"
      >
        {/* Header Photo */}
        <div className="relative h-64 bg-slate-100 dark:bg-slate-800">
          <img src={location.image} alt={location.title} className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/40 to-transparent"></div>

          <button
            onClick={onClose}
            className="absolute top-6 right-6 p-3 rounded-full bg-white/90 dark:bg-slate-800/90 text-slate-900 dark:text-white hover:scale-110 active:scale-95 transition-all shadow-xl backdrop-blur-md cursor-pointer"
          >
            <X className="h-6 w-6" />
          </button>

          <div className="absolute bottom-6 left-8 right-8 space-y-2">
            <div className="flex items-center space-x-3">
              <span className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-black text-xs uppercase px-3.5 py-1 rounded-xl shadow-md">
                {location.type}
              </span>
              <span className="bg-slate-950/80 backdrop-blur-md text-amber-400 font-bold text-xs px-3.5 py-1 rounded-xl shadow-md flex items-center space-x-1">
                <Navigation className="h-3.5 w-3.5 text-amber-400" />
                <span>{location.metroDistance}</span>
              </span>
            </div>
            <h2 className="text-3xl font-black text-white font-display">{location.title}</h2>
            <p className="text-xs text-slate-300 flex items-center space-x-1 font-medium">
              <MapPin className="h-4 w-4 text-emerald-400 shrink-0" />
              <span>{location.address}</span>
            </p>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-8 space-y-8 max-h-[55vh] overflow-y-auto">
          {/* Owner & Operating Info */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-indigo-50/40 dark:bg-slate-800/50 p-6 rounded-3xl border border-indigo-100/50 dark:border-slate-800">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 rounded-2xl bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-bold">
                <User className="h-6 w-6" />
              </div>
              <div>
                <span className="text-[10px] text-slate-400 dark:text-slate-500 uppercase tracking-widest block font-black">
                  Facility Host
                </span>
                <p className="text-base font-black text-slate-900 dark:text-white flex items-center space-x-1">
                  <span>{location.ownerName}</span>
                  {location.verified && <ShieldCheck className="h-4 w-4 text-indigo-500" />}
                </p>
                <p className="text-xs text-slate-500 dark:text-slate-400 font-mono font-medium">{location.ownerContact}</p>
              </div>
            </div>

            <div className="flex items-center space-x-4 border-t md:border-t-0 md:border-l border-indigo-100/60 dark:border-slate-700/50 pt-4 md:pt-0 md:pl-6">
              <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 text-emerald-500 flex items-center justify-center font-bold">
                <Clock className="h-6 w-6" />
              </div>
              <div>
                <span className="text-[10px] text-slate-400 dark:text-slate-500 uppercase tracking-widest block font-black">
                  Operating Window
                </span>
                <p className="text-base font-black text-slate-900 dark:text-white">{location.operatingHours}</p>
                <p className="text-xs text-emerald-500 font-bold">Verified Real-Time Access</p>
              </div>
            </div>
          </div>

          {/* Slot Grid Selection */}
          <div>
            <div className="flex justify-between items-center mb-4">
              <div>
                <h3 className="text-lg font-black text-slate-900 dark:text-white flex items-center space-x-2 font-display">
                  <Car className="h-5 w-5 text-indigo-500" />
                  <span>Select Your Preferred Bay</span>
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                  Click an open bay to reserve your exact spot
                </p>
              </div>
              <div className="flex items-center space-x-4 text-xs font-black">
                <span className="flex items-center space-x-1.5 text-emerald-500">
                  <span className="w-3 h-3 rounded-full bg-emerald-500"></span>
                  <span>Available</span>
                </span>
                <span className="flex items-center space-x-1.5 text-rose-500">
                  <span className="w-3 h-3 rounded-full bg-rose-500"></span>
                  <span>Occupied</span>
                </span>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
              {location.slots.map((slot) => {
                const isOccupied = slot.status === 'OCCUPIED';
                const isSelected = selectedSlotId === slot.id;

                return (
                  <button
                    key={slot.id}
                    disabled={isOccupied}
                    onClick={() => setSelectedSlotId(slot.id)}
                    className={`p-4 rounded-2xl border text-left transition-all relative cursor-pointer ${
                      isOccupied
                        ? 'bg-rose-50/50 dark:bg-rose-950/20 border-rose-200 dark:border-rose-900 text-rose-400 cursor-not-allowed opacity-60'
                        : isSelected
                        ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white border-indigo-600 shadow-xl shadow-indigo-500/25 scale-105'
                        : 'bg-indigo-50/30 dark:bg-slate-800/80 border-indigo-100/50 dark:border-slate-700 text-slate-800 dark:text-slate-200 hover:bg-indigo-50/80 dark:hover:bg-slate-700'
                    }`}
                  >
                    <div className="flex justify-between items-start mb-2">
                      <span className="font-black text-base font-mono">Bay {slot.id}</span>
                      {slot.type === 'EV' ? (
                        <Zap className={`h-4 w-4 ${isSelected ? 'text-white' : 'text-emerald-500 fill-current'}`} />
                      ) : (
                        <span className={`text-[10px] px-2 py-0.5 rounded-lg font-mono font-bold ${
                          isSelected ? 'bg-white/20 text-white' : 'bg-indigo-100/60 dark:bg-slate-700 text-indigo-700 dark:text-slate-300'
                        }`}>
                          {slot.type}
                        </span>
                      )}
                    </div>
                    <div className={`text-xs font-bold ${isSelected ? 'text-white/80' : 'text-slate-500 dark:text-slate-400'}`}>
                      {isOccupied ? 'Occupied' : `₹${slot.basePrice}/hr`}
                    </div>

                    {isSelected && (
                      <CheckCircle className="h-5 w-5 text-white absolute bottom-3 right-3" />
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Amenities */}
          <div>
            <h4 className="text-xs font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest mb-3">
              Facility Amenities
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {location.amenities.map((amenity) => (
                <div
                  key={amenity}
                  className="flex items-center space-x-2.5 p-3 rounded-2xl bg-indigo-50/30 dark:bg-slate-800/60 border border-indigo-100/50 dark:border-slate-700/50 text-xs font-bold text-slate-700 dark:text-slate-300"
                >
                  <span className="text-emerald-500 font-black">✓</span>
                  <span>{amenity}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-8 bg-indigo-50/40 dark:bg-slate-800/40 border-t border-indigo-100/60 dark:border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-6">
          <div>
            <span className="text-xs text-slate-500 dark:text-slate-400 block font-medium">
              Selected Bay: <strong className="text-slate-900 dark:text-white font-black">Slot #{selectedSlot?.id} ({selectedSlot?.type})</strong>
            </span>
            <div className="flex items-baseline space-x-1">
              <span className="text-3xl font-black text-emerald-500 font-mono">
                {location.pricing.currency}{selectedSlot?.basePrice || location.pricing.hourly}
              </span>
              <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">/ hour rate</span>
            </div>
          </div>

          <div className="flex items-center space-x-4 w-full sm:w-auto">
            <button
              onClick={onClose}
              className="bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 px-6 py-4 rounded-2xl font-black text-sm hover:bg-indigo-50 dark:hover:bg-slate-700 transition-all border border-indigo-100 dark:border-slate-700 cursor-pointer flex-1 sm:flex-none"
            >
              Cancel
            </button>
            <button
              disabled={!selectedSlot || selectedSlot.status === 'OCCUPIED'}
              onClick={() => onProceedToBooking(location, selectedSlot)}
              className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-8 py-4 rounded-2xl font-black text-sm hover:opacity-90 transition-all flex items-center justify-center space-x-2 cursor-pointer shadow-xl shadow-indigo-500/25 flex-1 sm:flex-none"
            >
              <span>Reserve Bay {selectedSlot?.id}</span>
              <ArrowRight className="h-5 w-5" />
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
