import React from 'react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import L from 'leaflet';
import { MapPin, Navigation, Star, ShieldCheck, ArrowRight } from 'lucide-react';
import { useTheme } from '../../context/ThemeContext';

export default function MapView({ locations, onSelectLocation }) {
  const { isDarkMode } = useTheme();
  const defaultCenter = [28.5800, 77.1800];
  const defaultZoom = 11;

  const createCustomIcon = (location) => {
    const isAvailable = location.availableSlots > 0;
    const priceText = `${location.pricing.currency}${location.pricing.hourly}`;
    const slotsText = `${location.availableSlots} free`;

    const htmlContent = `
      <div style="
        background: ${isDarkMode ? '#030712' : '#ffffff'};
        border: 2px solid ${isAvailable ? '#6366f1' : '#e11d48'};
        box-shadow: 0 10px 25px rgba(99, 102, 241, 0.3);
        color: ${isDarkMode ? '#ffffff' : '#0f172a'};
        border-radius: 16px;
        padding: 6px 12px;
        font-family: 'Plus Jakarta Sans', sans-serif;
        font-weight: 800;
        font-size: 12px;
        white-space: nowrap;
        display: flex;
        align-items: center;
        gap: 6px;
        cursor: pointer;
        transform: translate(-50%, -100%);
      ">
        <span style="background: ${isAvailable ? '#10b981' : '#e11d48'}; width: 10px; height: 10px; border-radius: 50%; display: inline-block;"></span>
        <span>${priceText}/hr</span>
        <span style="background: ${isDarkMode ? '#1e293b' : '#eef2ff'}; color: ${isDarkMode ? '#94a3b8' : '#4338ca'}; padding: 2px 6px; border-radius: 8px; font-size: 10px; border: 1px solid ${isDarkMode ? '#334155' : '#c7d2fe'}; font-weight: 700;">${slotsText}</span>
      </div>
    `;

    return L.divIcon({
      html: htmlContent,
      className: 'custom-leaflet-pin',
      iconSize: [120, 40],
      iconAnchor: [60, 40]
    });
  };

  const tileUrl = isDarkMode
    ? "https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
    : "https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png";

  return (
    <div className="bg-white dark:bg-slate-900 rounded-[32px] overflow-hidden shadow-xl border border-indigo-100/60 dark:border-slate-800 relative h-[600px] w-full transition-colors duration-500">
      {/* Header Overlay */}
      <div className="absolute top-5 left-5 z-[1000] bg-white/90 dark:bg-slate-900/90 backdrop-blur-md p-4 rounded-2xl border border-indigo-100 dark:border-slate-800 shadow-xl flex items-center space-x-3 max-w-sm">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-600 to-purple-600 text-white flex items-center justify-center font-black shadow-md shadow-indigo-500/20">
          <Navigation className="h-5 w-5" />
        </div>
        <div>
          <h4 className="text-xs font-black text-slate-900 dark:text-white uppercase tracking-wider font-display">
            Live Transit Map
          </h4>
          <p className="text-[11px] text-indigo-500 dark:text-indigo-400 font-bold">
            {locations.length} Verified Parking Hubs
          </p>
        </div>
      </div>

      <MapContainer
        center={defaultCenter}
        zoom={defaultZoom}
        scrollWheelZoom={true}
        style={{ height: '100%', width: '100%', borderRadius: '2rem' }}
      >
        <TileLayer
          key={isDarkMode ? 'dark' : 'light'}
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url={tileUrl}
        />

        {locations.map((loc) => (
          <Marker
            key={loc.id}
            position={[loc.lat, loc.lng]}
            icon={createCustomIcon(loc)}
          >
            <Popup className="custom-map-popup">
              <div className="w-64 p-1 font-sans text-slate-900 dark:text-white">
                <div className="relative h-32 rounded-2xl overflow-hidden mb-3">
                  <img src={loc.image} alt={loc.title} className="w-full h-full object-cover" />
                  <div className="absolute top-2 right-2 bg-slate-950/80 backdrop-blur-md px-2.5 py-1 rounded-xl text-[10px] font-bold text-white flex items-center space-x-1">
                    <Star className="h-3 w-3 text-amber-400 fill-current" />
                    <span>{loc.rating}</span>
                  </div>
                  {loc.verified && (
                    <div className="absolute top-2 left-2 bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-2.5 py-1 rounded-xl text-[10px] font-black flex items-center space-x-1 shadow-md">
                      <ShieldCheck className="h-3 w-3" />
                      <span>Verified</span>
                    </div>
                  )}
                </div>

                <h3 className="font-black text-sm text-slate-900 dark:text-white line-clamp-1 mb-1">{loc.title}</h3>
                <p className="text-[11px] text-indigo-600 dark:text-indigo-400 font-bold mb-1 flex items-center space-x-1">
                  <Navigation className="h-3 w-3 text-emerald-500" />
                  <span>{loc.metroDistance}</span>
                </p>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-1 mb-3">{loc.address}</p>

                <div className="flex items-center justify-between pt-2 border-t border-indigo-50 dark:border-slate-800 mb-3">
                  <div>
                    <span className="text-[9px] text-slate-400 block font-black uppercase tracking-widest">Rate</span>
                    <span className="text-sm font-black text-emerald-500 font-mono">
                      {loc.pricing.currency}{loc.pricing.hourly}/hr
                    </span>
                  </div>
                  <div className="text-right">
                    <span className="text-[9px] text-slate-400 block font-black uppercase tracking-widest">Open</span>
                    <span className="text-xs font-bold text-indigo-500">
                      {loc.availableSlots} of {loc.totalSlots} Slots
                    </span>
                  </div>
                </div>

                <button
                  onClick={() => onSelectLocation(loc)}
                  className="w-full py-2.5 bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-black text-xs rounded-xl flex items-center justify-center space-x-2 transition-all hover:opacity-90 cursor-pointer shadow-md"
                >
                  <span>Select & Reserve</span>
                  <ArrowRight className="h-4 w-4" />
                </button>
              </div>
            </Popup>
          </Marker>
        ))}
      </MapContainer>
    </div>
  );
}
