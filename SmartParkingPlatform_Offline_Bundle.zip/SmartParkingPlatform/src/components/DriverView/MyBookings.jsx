import React, { useState, useEffect } from 'react';
import { Clock, Navigation, QrCode, AlertCircle, CheckCircle2, XCircle, Plus, ChevronRight, Car, MapPin } from 'lucide-react';
import { motion } from 'framer-motion';

export default function MyBookings({ bookings, onExtendBooking, onCancelBooking, onViewPass }) {
  const [now, setNow] = useState(Date.now());

  useEffect(() => {
    const timer = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(timer);
  }, []);

  const formatRemainingTime = (endTimeStr) => {
    const end = new Date(endTimeStr).getTime();
    const diff = end - now;

    if (diff <= 0) return 'Expired / Completed';

    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((diff % (1000 * 60)) / 1000);

    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-black text-slate-900 dark:text-white tracking-tight flex items-center space-x-3 font-display">
            <Clock className="h-8 w-8 text-indigo-600 dark:text-indigo-400" />
            <span>My Reserved Parking Sessions</span>
          </h2>
          <p className="text-slate-500 dark:text-slate-400 mt-2 text-base font-medium">
            Track live session countdowns, extend durations, or retrieve digital QR gate passes
          </p>
        </div>
        <span className="bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border border-indigo-500/20 px-5 py-2 rounded-2xl font-black text-xs uppercase tracking-widest">
          {bookings.length} Total Reservations
        </span>
      </div>

      {bookings.length === 0 ? (
        <div className="bg-white dark:bg-slate-900 p-16 text-center rounded-[40px] border border-indigo-100/60 dark:border-slate-800 shadow-xl space-y-4">
          <div className="w-20 h-20 bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 rounded-3xl flex items-center justify-center mx-auto">
            <Car className="h-10 w-10" />
          </div>
          <h3 className="text-2xl font-black text-slate-900 dark:text-white">No Active Parking Bookings</h3>
          <p className="text-slate-500 dark:text-slate-400 max-w-md mx-auto font-medium">
            You haven't reserved any parking slots yet. Search nearby metro stations on the discover tab to book!
          </p>
        </div>
      ) : (
        <div className="space-y-6">
          {bookings.map((booking) => {
            const isActive = booking.status === 'ACTIVE';
            const isUpcoming = booking.status === 'UPCOMING';
            const isCompleted = booking.status === 'COMPLETED';

            return (
              <motion.div
                key={booking.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className={`bg-white dark:bg-slate-900 p-8 rounded-[36px] border transition-all shadow-xl ${
                  isActive
                    ? 'border-emerald-500/50 dark:border-emerald-500/50 ring-1 ring-emerald-500/30'
                    : 'border-indigo-100/60 dark:border-slate-800'
                }`}
              >
                <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 pb-6 border-b border-indigo-50 dark:border-slate-800">
                  <div className="flex items-center space-x-4">
                    <div
                      className={`w-16 h-16 rounded-2xl flex items-center justify-center font-black ${
                        isActive
                          ? 'bg-emerald-500/10 text-emerald-500 border border-emerald-500/20'
                          : 'bg-indigo-500/10 text-indigo-500 border border-indigo-500/20'
                      }`}
                    >
                      <Car className="h-8 w-8" />
                    </div>
                    <div>
                      <div className="flex items-center space-x-3">
                        <h3 className="font-black text-xl text-slate-900 dark:text-white">{booking.locationTitle}</h3>
                        <span
                          className={`px-3.5 py-1 rounded-full text-xs font-black uppercase tracking-wider ${
                            isActive
                              ? 'bg-emerald-500 text-white'
                              : isUpcoming
                              ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white'
                              : 'bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                          }`}
                        >
                          {booking.status}
                        </span>
                      </div>
                      <p className="text-xs text-slate-500 dark:text-slate-400 flex items-center space-x-1 mt-1 font-medium">
                        <MapPin className="h-3.5 w-3.5 text-slate-400 shrink-0" />
                        <span>{booking.address}</span>
                      </p>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="text-[10px] text-slate-400 dark:text-slate-500 font-mono block font-black uppercase tracking-widest">
                      REF: {booking.id}
                    </span>
                    <span className="text-2xl font-black text-emerald-500 font-mono">
                      ₹{booking.totalPrice}
                    </span>
                  </div>
                </div>

                <div className="py-6 grid grid-cols-2 md:grid-cols-4 gap-6 text-xs">
                  <div className="bg-indigo-50/40 dark:bg-slate-800/60 p-4 rounded-2xl">
                    <span className="text-slate-400 dark:text-slate-500 text-[10px] block font-black uppercase tracking-widest mb-1">
                      Reserved Bay
                    </span>
                    <span className="font-black text-indigo-600 dark:text-indigo-400 text-base font-mono">Slot #{booking.slotId}</span>
                  </div>
                  <div className="bg-indigo-50/40 dark:bg-slate-800/60 p-4 rounded-2xl">
                    <span className="text-slate-400 dark:text-slate-500 text-[10px] block font-black uppercase tracking-widest mb-1">
                      Vehicle Plate
                    </span>
                    <span className="font-black text-slate-900 dark:text-white font-mono">{booking.vehicleNumber}</span>
                  </div>
                  <div className="bg-indigo-50/40 dark:bg-slate-800/60 p-4 rounded-2xl">
                    <span className="text-slate-400 dark:text-slate-500 text-[10px] block font-black uppercase tracking-widest mb-1">
                      Duration
                    </span>
                    <span className="font-black text-slate-900 dark:text-white">{booking.durationHours} Hours</span>
                  </div>
                  <div className="bg-indigo-50/40 dark:bg-slate-800/60 p-4 rounded-2xl">
                    <span className="text-slate-400 dark:text-slate-500 text-[10px] block font-black uppercase tracking-widest mb-1">
                      {isActive ? 'Remaining Time' : 'Status'}
                    </span>
                    <span className={`font-mono text-sm font-black ${isActive ? 'text-emerald-500' : 'text-slate-700 dark:text-slate-300'}`}>
                      {isActive ? formatRemainingTime(booking.endTime) : booking.status}
                    </span>
                  </div>
                </div>

                <div className="pt-4 border-t border-indigo-50 dark:border-slate-800 flex flex-wrap items-center justify-between gap-4">
                  <div className="flex items-center space-x-3">
                    <button
                      onClick={() => onViewPass(booking)}
                      className="bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 dark:bg-indigo-950/50 px-5 py-3 rounded-2xl text-xs font-black hover:bg-indigo-600 hover:text-white transition-all flex items-center space-x-2 cursor-pointer"
                    >
                      <QrCode className="h-4 w-4" />
                      <span>Digital QR Gate Pass</span>
                    </button>
                    <button
                      onClick={() => alert(`Launching GPS turn-by-turn navigation to ${booking.address}`)}
                      className="bg-indigo-50/60 dark:bg-slate-800 text-slate-700 dark:text-slate-300 px-5 py-3 rounded-2xl text-xs font-black hover:bg-indigo-100 dark:hover:bg-slate-700 transition-all flex items-center space-x-2 cursor-pointer"
                    >
                      <Navigation className="h-4 w-4 text-emerald-500" />
                      <span>Get Directions</span>
                    </button>
                  </div>

                  <div className="flex items-center space-x-3">
                    {isActive && (
                      <button
                        onClick={() => onExtendBooking(booking.id)}
                        className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-6 py-3 rounded-2xl text-xs font-black hover:opacity-90 transition-all flex items-center space-x-2 cursor-pointer shadow-lg shadow-indigo-500/20"
                      >
                        <Plus className="h-4 w-4" />
                        <span>Extend +1 Hour</span>
                      </button>
                    )}
                    {(isActive || isUpcoming) && (
                      <button
                        onClick={() => onCancelBooking(booking.id)}
                        className="px-5 py-3 rounded-2xl text-xs font-black text-rose-500 bg-rose-50 dark:bg-rose-950/30 hover:bg-rose-500 hover:text-white transition-all cursor-pointer"
                      >
                        Cancel Booking
                      </button>
                    )}
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
}
