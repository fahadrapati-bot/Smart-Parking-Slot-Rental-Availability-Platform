import React, { useState } from 'react';
import { Home, Plus, DollarSign, Car, Calendar, Lock, Unlock, CheckCircle, XCircle, ShieldCheck, MapPin, Zap, TrendingUp, AlertTriangle, Activity, Package } from 'lucide-react';
import { motion } from 'framer-motion';

export default function OwnerDashboard({ locations, onAddNewLocation, onToggleSlotStatus }) {
  const [showAddModal, setShowAddModal] = useState(false);
  const [pendingRequests, setPendingRequests] = useState([
    {
      id: 'req-301',
      driverName: 'Vikram Singh',
      vehiclePlate: 'DL 03 CA 9012',
      vehicleType: 'SUV',
      slotRequested: 'A-03',
      locationTitle: 'Rajiv Chowk Metro Private Underground Garage',
      duration: '4 Hours (05:00 PM - 09:00 PM)',
      price: 160,
      timestamp: '10 mins ago'
    },
    {
      id: 'req-302',
      driverName: 'Neha Kapoor',
      vehiclePlate: 'HR 26 EX 1144',
      vehicleType: 'EV',
      slotRequested: 'A-01',
      locationTitle: 'DLF Cyber City Tech Tower Driveway',
      duration: '8 Hours (09:00 AM - 05:00 PM)',
      price: 440,
      timestamp: '25 mins ago'
    }
  ]);

  const [newSpaceForm, setNewSpaceForm] = useState({
    title: '',
    address: '',
    metroDistance: '',
    type: 'Private Driveway',
    totalSlots: 6,
    hourlyPrice: 40,
    dailyPrice: 350,
    monthlyPrice: 6000,
    allowedVehicles: ['2-wheeler', 'Sedan', 'SUV'],
    amenities: ['CCTV Surveillance', '24/7 Security Guard', 'Gated Access'],
    image: 'https://images.unsplash.com/photo-1506521781263-d8422e82f27a?auto=format&fit=crop&w=1000&q=80'
  });

  const handleApproveRequest = (reqId) => {
    setPendingRequests(pendingRequests.filter((r) => r.id !== reqId));
    alert('Booking Request Approved! Driver notified via SMS.');
  };

  const handleDeclineRequest = (reqId) => {
    setPendingRequests(pendingRequests.filter((r) => r.id !== reqId));
    alert('Booking Request Declined.');
  };

  const handleAddSubmit = (e) => {
    e.preventDefault();
    if (!newSpaceForm.title || !newSpaceForm.address) return;

    const slots = [];
    for (let i = 1; i <= newSpaceForm.totalSlots; i++) {
      slots.push({
        id: `P-${i}`,
        type: i % 2 === 0 ? '4-Wheeler' : '2-Wheeler',
        vehicleCompatibility: ['Sedan', '2-wheeler'],
        status: 'AVAILABLE',
        basePrice: newSpaceForm.hourlyPrice
      });
    }

    const newLoc = {
      id: `loc-${Date.now()}`,
      title: newSpaceForm.title,
      ownerId: 'owner-me',
      ownerName: 'Rajesh Sharma (You)',
      ownerContact: '+91 98765 43210',
      rating: 5.0,
      reviewsCount: 1,
      verified: true,
      address: newSpaceForm.address,
      metroDistance: newSpaceForm.metroDistance || '200m from nearest metro',
      lat: 28.6328 + (Math.random() - 0.5) * 0.05,
      lng: 77.2197 + (Math.random() - 0.5) * 0.05,
      image: newSpaceForm.image,
      type: newSpaceForm.type,
      totalSlots: Number(newSpaceForm.totalSlots),
      availableSlots: Number(newSpaceForm.totalSlots),
      pricing: {
        hourly: Number(newSpaceForm.hourlyPrice),
        daily: Number(newSpaceForm.dailyPrice),
        monthly: Number(newSpaceForm.monthlyPrice),
        currency: '₹'
      },
      allowedVehicles: newSpaceForm.allowedVehicles,
      amenities: newSpaceForm.amenities,
      operatingHours: '06:00 AM - 11:00 PM',
      slots
    };

    onAddNewLocation(newLoc);
    setShowAddModal(false);
    alert('🎉 New Parking Space Listed Successfully!');
  };

  return (
    <div className="space-y-10">
      {/* Header */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div>
          <h1 className="text-4xl font-black text-slate-900 dark:text-white tracking-tight flex items-center space-x-3 font-display">
            <Home className="h-10 w-10 text-indigo-600 dark:text-indigo-400" />
            <span>Host Command Center</span>
          </h1>
          <p className="text-slate-500 dark:text-slate-400 mt-2 text-lg font-medium">
            Monetize unused driveways & garages, manage slot schedules, and track monthly earnings
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-8 py-4 rounded-2xl font-black text-base transition-all hover:opacity-90 flex items-center space-x-2 cursor-pointer shadow-xl shadow-indigo-500/25"
        >
          <Plus className="h-5 w-5" />
          <span>List New Parking Space</span>
        </button>
      </div>

      {/* KPI Overview Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border border-indigo-100/60 dark:border-slate-800 shadow-sm dark:shadow-none">
          <div className="flex items-center justify-between mb-4">
            <div className="bg-emerald-500/10 p-3.5 rounded-2xl text-emerald-500">
              <DollarSign className="h-8 w-8" />
            </div>
            <span className="text-slate-400 dark:text-slate-500 text-xs font-black uppercase tracking-widest">
              Earnings
            </span>
          </div>
          <span className="text-4xl font-black text-slate-900 dark:text-white font-mono">₹38,450</span>
          <p className="text-slate-500 dark:text-slate-400 mt-2 text-xs font-bold flex items-center space-x-1">
            <TrendingUp className="h-4 w-4 text-emerald-500 inline mr-1" />
            <span className="text-emerald-500">+24% from last month</span>
          </p>
        </div>

        <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border border-indigo-100/60 dark:border-slate-800 shadow-sm dark:shadow-none">
          <div className="flex items-center justify-between mb-4">
            <div className="bg-indigo-500/10 p-3.5 rounded-2xl text-indigo-500">
              <Package className="h-8 w-8" />
            </div>
            <span className="text-slate-400 dark:text-slate-500 text-xs font-black uppercase tracking-widest">
              Facilities
            </span>
          </div>
          <span className="text-4xl font-black text-slate-900 dark:text-white font-mono">22 Bays</span>
          <p className="text-slate-500 dark:text-slate-400 mt-2 text-xs font-bold">3 Active Facilities</p>
        </div>

        <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border border-indigo-100/60 dark:border-slate-800 shadow-sm dark:shadow-none">
          <div className="flex items-center justify-between mb-4">
            <div className="bg-purple-500/10 p-3.5 rounded-2xl text-purple-500">
              <Activity className="h-8 w-8" />
            </div>
            <span className="text-slate-400 dark:text-slate-500 text-xs font-black uppercase tracking-widest">
              Occupancy
            </span>
          </div>
          <span className="text-4xl font-black text-slate-900 dark:text-white font-mono">78.4%</span>
          <p className="text-slate-500 dark:text-slate-400 mt-2 text-xs font-bold">Peak Yield (08 AM - 06 PM)</p>
        </div>

        <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border border-indigo-100/60 dark:border-slate-800 shadow-sm dark:shadow-none">
          <div className="flex items-center justify-between mb-4">
            <div className="bg-amber-500/10 p-3.5 rounded-2xl text-amber-500">
              <AlertTriangle className="h-8 w-8" />
            </div>
            <span className="text-slate-400 dark:text-slate-500 text-xs font-black uppercase tracking-widest">
              Approvals
            </span>
          </div>
          <span className="text-4xl font-black text-amber-500 font-mono">{pendingRequests.length} Pending</span>
          <p className="text-slate-500 dark:text-slate-400 mt-2 text-xs font-bold">Action Required</p>
        </div>
      </div>

      {/* Pending Driver Approval Requests */}
      {pendingRequests.length > 0 && (
        <div className="bg-amber-500/10 border border-amber-500/20 p-8 rounded-[40px] space-y-4">
          <div className="flex items-center space-x-3 mb-2">
            <AlertTriangle className="h-6 w-6 text-amber-500" />
            <h3 className="text-xl font-black text-slate-900 dark:text-white font-display">
              Pending Driver Approval Requests
            </h3>
          </div>

          <div className="space-y-4">
            {pendingRequests.map((req) => (
              <div
                key={req.id}
                className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-indigo-100/60 dark:border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-6 shadow-sm"
              >
                <div>
                  <div className="flex items-center space-x-3 mb-1">
                    <span className="font-black text-lg text-slate-900 dark:text-white">{req.driverName}</span>
                    <span className="px-3 py-1 bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 rounded-full text-xs font-black">
                      {req.vehicleType}
                    </span>
                    <span className="text-xs text-slate-400 font-mono">({req.vehiclePlate})</span>
                  </div>
                  <p className="text-sm text-slate-600 dark:text-slate-300 font-medium">
                    Requested Slot <strong className="text-indigo-600 dark:text-indigo-400">{req.slotRequested}</strong> at {req.locationTitle}
                  </p>
                  <p className="text-xs text-slate-400 font-medium">{req.duration} • Received {req.timestamp}</p>
                </div>

                <div className="flex items-center space-x-4">
                  <span className="text-2xl font-black text-emerald-500 font-mono">₹{req.price}</span>
                  <button
                    onClick={() => handleApproveRequest(req.id)}
                    className="bg-emerald-500 text-white px-6 py-3 rounded-2xl text-xs font-black hover:opacity-90 transition-all cursor-pointer shadow-md shadow-emerald-500/20"
                  >
                    Approve Request
                  </button>
                  <button
                    onClick={() => handleDeclineRequest(req.id)}
                    className="bg-indigo-50/60 dark:bg-slate-800 text-slate-600 dark:text-slate-300 px-5 py-3 rounded-2xl text-xs font-black hover:bg-indigo-100 dark:hover:bg-slate-700 transition-all cursor-pointer"
                  >
                    Decline
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Listed Facilities & Slot Locker Grid */}
      <div className="space-y-6">
        <h3 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight font-display">
          Your Listed Facilities & Slot Availability Locker
        </h3>

        <div className="grid grid-cols-1 gap-6">
          {locations.map((loc) => (
            <div
              key={loc.id}
              className="bg-white dark:bg-slate-900 p-8 rounded-[40px] border border-indigo-100/60 dark:border-slate-800 shadow-sm space-y-6"
            >
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 pb-6 border-b border-indigo-50 dark:border-slate-800">
                <div className="flex items-center space-x-5">
                  <img
                    src={loc.image}
                    alt={loc.title}
                    className="w-20 h-20 rounded-2xl object-cover border border-indigo-100 dark:border-slate-700"
                  />
                  <div>
                    <div className="flex items-center space-x-3">
                      <h4 className="font-black text-xl text-slate-900 dark:text-white">{loc.title}</h4>
                      <span className="bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 px-3 py-1 rounded-full text-xs font-black">
                        Verified Facility
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 dark:text-slate-400 flex items-center space-x-1 mt-1 font-medium">
                      <MapPin className="h-4 w-4 text-indigo-500" /> <span>{loc.address}</span>
                    </p>
                  </div>
                </div>

                <div className="flex items-center space-x-6 text-right">
                  <div>
                    <span className="text-[10px] text-slate-400 dark:text-slate-500 uppercase font-black tracking-widest block">
                      Hourly Rate
                    </span>
                    <span className="text-xl font-black text-emerald-500 font-mono">₹{loc.pricing.hourly}/hr</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 dark:text-slate-500 uppercase font-black tracking-widest block">
                      Availability
                    </span>
                    <span className="text-sm font-black text-indigo-600 dark:text-indigo-400">
                      {loc.availableSlots} of {loc.totalSlots} free
                    </span>
                  </div>
                </div>
              </div>

              {/* Slot Locker Grid */}
              <div>
                <p className="text-xs font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest mb-3">
                  Interactive Slot Locker (Click bay to toggle Available vs Blocked):
                </p>
                <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-3">
                  {loc.slots.map((s) => {
                    const isAvailable = s.status === 'AVAILABLE';
                    return (
                      <button
                        key={s.id}
                        onClick={() => onToggleSlotStatus(loc.id, s.id)}
                        className={`p-4 rounded-2xl border text-xs text-left transition-all cursor-pointer ${
                          isAvailable
                            ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-500 hover:bg-emerald-500/20'
                            : 'bg-rose-500/10 border-rose-500/30 text-rose-500 hover:bg-rose-500/20'
                        }`}
                      >
                        <div className="flex justify-between items-center mb-1">
                          <span className="font-mono font-black text-sm">Bay {s.id}</span>
                          {isAvailable ? <Unlock className="h-4 w-4 text-emerald-500" /> : <Lock className="h-4 w-4 text-rose-500" />}
                        </div>
                        <span className="text-[10px] font-black uppercase tracking-wider block opacity-80">
                          {s.status}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Modal Add Facility */}
      {showAddModal && (
        <div
          className="fixed inset-0 bg-slate-950/70 backdrop-blur-md z-[200] flex items-center justify-center p-4 overflow-y-auto"
          onClick={() => setShowAddModal(false)}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="bg-white dark:bg-slate-900 w-full max-w-2xl rounded-[40px] p-10 shadow-2xl space-y-6 my-8 border border-indigo-100/60 dark:border-slate-800"
          >
            <h2 className="text-3xl font-black text-slate-900 dark:text-white font-display">List New Parking Facility</h2>

            <form onSubmit={handleAddSubmit} className="space-y-4">
              <div>
                <label className="text-xs font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest block mb-2">
                  Facility Name
                </label>
                <input
                  type="text"
                  required
                  value={newSpaceForm.title}
                  onChange={(e) => setNewSpaceForm({ ...newSpaceForm, title: e.target.value })}
                  placeholder="e.g. Connaught Place Secure Private Garage"
                  className="w-full px-6 py-4 rounded-2xl bg-indigo-50/40 dark:bg-slate-800 border border-indigo-100 dark:border-slate-700 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-indigo-500 font-bold text-sm"
                />
              </div>

              <div>
                <label className="text-xs font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest block mb-2">
                  Full Address
                </label>
                <input
                  type="text"
                  required
                  value={newSpaceForm.address}
                  onChange={(e) => setNewSpaceForm({ ...newSpaceForm, address: e.target.value })}
                  placeholder="e.g. Block C, Inner Circle, Connaught Place"
                  className="w-full px-6 py-4 rounded-2xl bg-indigo-50/40 dark:bg-slate-800 border border-indigo-100 dark:border-slate-700 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-indigo-500 font-bold text-sm"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest block mb-2">
                    Metro Proximity
                  </label>
                  <input
                    type="text"
                    value={newSpaceForm.metroDistance}
                    onChange={(e) => setNewSpaceForm({ ...newSpaceForm, metroDistance: e.target.value })}
                    placeholder="e.g. 100m from Rajiv Chowk Metro"
                    className="w-full px-6 py-4 rounded-2xl bg-indigo-50/40 dark:bg-slate-800 border border-indigo-100 dark:border-slate-700 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-indigo-500 font-bold text-sm"
                  />
                </div>
                <div>
                  <label className="text-xs font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest block mb-2">
                    Number of Bays
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="50"
                    value={newSpaceForm.totalSlots}
                    onChange={(e) => setNewSpaceForm({ ...newSpaceForm, totalSlots: e.target.value })}
                    className="w-full px-6 py-4 rounded-2xl bg-indigo-50/40 dark:bg-slate-800 border border-indigo-100 dark:border-slate-700 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-indigo-500 font-bold text-sm"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="text-xs font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest block mb-2">
                    Hourly Rate (₹)
                  </label>
                  <input
                    type="number"
                    value={newSpaceForm.hourlyPrice}
                    onChange={(e) => setNewSpaceForm({ ...newSpaceForm, hourlyPrice: e.target.value })}
                    className="w-full px-6 py-4 rounded-2xl bg-indigo-50/40 dark:bg-slate-800 border border-indigo-100 dark:border-slate-700 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-indigo-500 font-bold text-sm"
                  />
                </div>
                <div>
                  <label className="text-xs font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest block mb-2">
                    Daily Rate (₹)
                  </label>
                  <input
                    type="number"
                    value={newSpaceForm.dailyPrice}
                    onChange={(e) => setNewSpaceForm({ ...newSpaceForm, dailyPrice: e.target.value })}
                    className="w-full px-6 py-4 rounded-2xl bg-indigo-50/40 dark:bg-slate-800 border border-indigo-100 dark:border-slate-700 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-indigo-500 font-bold text-sm"
                  />
                </div>
                <div>
                  <label className="text-xs font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest block mb-2">
                    Monthly Rate (₹)
                  </label>
                  <input
                    type="number"
                    value={newSpaceForm.monthlyPrice}
                    onChange={(e) => setNewSpaceForm({ ...newSpaceForm, monthlyPrice: e.target.value })}
                    className="w-full px-6 py-4 rounded-2xl bg-indigo-50/40 dark:bg-slate-800 border border-indigo-100 dark:border-slate-700 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-indigo-500 font-bold text-sm"
                  />
                </div>
              </div>

              <div className="flex space-x-4 pt-4">
                <button
                  type="submit"
                  className="flex-1 bg-gradient-to-r from-indigo-600 to-purple-600 text-white py-4 rounded-2xl font-black text-base hover:opacity-90 transition shadow-xl"
                >
                  Publish Space
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 bg-indigo-50/60 dark:bg-slate-800 text-slate-600 dark:text-slate-400 py-4 rounded-2xl font-black text-base hover:bg-indigo-100 dark:hover:bg-slate-700 transition"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
