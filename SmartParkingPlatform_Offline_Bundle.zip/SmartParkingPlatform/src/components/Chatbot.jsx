import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MessageCircle, X, Send, Bot, Sparkles, Navigation, Car, Zap } from 'lucide-react';

const Chatbot = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState([
    { role: 'bot', content: 'Hi! I am your ParkSpot AI Parking Assistant. How can I help you find or host a parking space today?' }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMessage = { role: 'user', content: input };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);

    setTimeout(() => {
      let response = "I can help you locate verified parking bays near Rajiv Chowk, Cyber City, and Aerocity. What location are you heading to?";
      
      const lowerInput = input.toLowerCase();
      if (lowerInput.includes('metro') || lowerInput.includes('rajiv') || lowerInput.includes('cyber')) {
        response = "We have active real-time bays available at Rajiv Chowk Metro Hub and Cyber City Tech Tower starting at ₹40/hr.";
      } else if (lowerInput.includes('ev') || lowerInput.includes('electric') || lowerInput.includes('charge')) {
        response = "Electric vehicle charging is available! You can filter locations by EV Charger or select EV bays during checkout.";
      } else if (lowerInput.includes('host') || lowerInput.includes('owner') || lowerInput.includes('rent my space')) {
        response = "You can earn up to ₹35,000/month by hosting your driveway! Switch to 'Host a Space' mode in the top navbar to list your spot.";
      } else if (lowerInput.includes('hi') || lowerInput.includes('hello')) {
        response = "Hello! Looking for hassle-free smart parking or wanting to monetize your driveway?";
      } else if (lowerInput.includes('cancel') || lowerInput.includes('refund')) {
        response = "Reservations can be cancelled anytime under 'My Reservations' before your time slot starts.";
      }

      setMessages(prev => [...prev, { role: 'bot', content: response }]);
      setIsTyping(false);
    }, 1200);
  };

  return (
    <div className="fixed right-8 bottom-8 z-[100]">
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className="absolute bottom-20 right-0 w-96 h-[500px] bg-white dark:bg-slate-900 rounded-[32px] shadow-2xl border border-indigo-100 dark:border-slate-800 flex flex-col overflow-hidden"
          >
            {/* Header */}
            <div className="bg-gradient-to-r from-indigo-600 to-purple-600 p-6 flex items-center justify-between">
              <div className="flex items-center space-x-3 text-white">
                <div className="bg-white/20 p-2.5 rounded-xl">
                  <Bot className="h-6 w-6" />
                </div>
                <div>
                  <h3 className="font-black text-sm uppercase tracking-widest">ParkSpot AI Assistant</h3>
                  <p className="text-[10px] opacity-90 font-bold flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span> Live Guidance
                  </p>
                </div>
              </div>
              <button onClick={() => setIsOpen(false)} className="text-white/80 hover:text-white transition-colors cursor-pointer">
                <X className="h-6 w-6" />
              </button>
            </div>

            {/* Messages */}
            <div ref={scrollRef} className="flex-grow p-6 overflow-y-auto space-y-4 bg-indigo-50/20 dark:bg-slate-900/50">
              {messages.map((msg, i) => (
                <motion.div
                  initial={{ opacity: 0, x: msg.role === 'user' ? 10 : -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  key={i}
                  className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div className={`max-w-[80%] p-4 rounded-2xl text-sm font-medium ${
                    msg.role === 'user' 
                      ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-tr-none shadow-md shadow-indigo-500/20' 
                      : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 shadow-sm border border-indigo-100/50 dark:border-slate-700 rounded-tl-none'
                  }`}>
                    {msg.content}
                  </div>
                </motion.div>
              ))}
              {isTyping && (
                <div className="flex justify-start">
                  <div className="bg-white dark:bg-slate-800 p-4 rounded-2xl shadow-sm border border-indigo-100/50 dark:border-slate-700 rounded-tl-none">
                    <div className="flex space-x-1">
                      <div className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-bounce" />
                      <div className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-bounce [animation-delay:0.2s]" />
                      <div className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-bounce [animation-delay:0.4s]" />
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Input */}
            <div className="p-4 bg-white dark:bg-slate-900 border-t border-indigo-50 dark:border-slate-800">
              <div className="relative">
                <input
                  type="text"
                  placeholder="Ask about parking, EV bays, pricing..."
                  className="w-full pl-4 pr-12 py-3 bg-indigo-50/50 dark:bg-slate-800 border-none rounded-2xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all text-sm font-bold text-slate-700 dark:text-slate-200"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                />
                <button
                  onClick={handleSend}
                  className="absolute right-2 top-1/2 -translate-y-1/2 p-2 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-xl hover:scale-105 active:scale-95 transition-all shadow-md shadow-indigo-500/20 cursor-pointer"
                >
                  <Send className="h-4 w-4" />
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <motion.button
        onClick={() => setIsOpen(!isOpen)}
        whileHover={{ scale: 1.08, rotate: 5 }}
        whileTap={{ scale: 0.95 }}
        className="h-16 w-16 bg-gradient-to-br from-indigo-600 via-indigo-700 to-purple-600 text-white rounded-2xl flex items-center justify-center shadow-[0_20px_50px_rgba(99,102,241,0.4)] cursor-pointer relative group"
      >
        <AnimatePresence mode="wait">
          {isOpen ? (
            <motion.div key="close" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <X className="h-8 w-8" />
            </motion.div>
          ) : (
            <motion.div key="open" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="relative">
              <MessageCircle className="h-8 w-8" />
              <div className="absolute -top-1 -right-1 h-5 w-5 bg-emerald-400 rounded-full flex items-center justify-center border-2 border-white text-[10px] font-black text-slate-900">1</div>
            </motion.div>
          )}
        </AnimatePresence>
        {!isOpen && (
          <div className="absolute right-full mr-4 bg-slate-900 dark:bg-white text-white dark:text-slate-900 px-4 py-2 rounded-xl text-xs font-black uppercase tracking-widest opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none shadow-xl">
            Ask ParkSpot AI
          </div>
        )}
      </motion.button>
    </div>
  );
};

export default Chatbot;
