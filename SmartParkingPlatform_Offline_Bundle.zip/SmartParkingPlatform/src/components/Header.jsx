import React from 'react';
import { Car, Home, Shield, FileText, Bell, Sparkles, Navigation, Sun, Moon, UserCheck, Zap } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { motion, AnimatePresence } from 'framer-motion';

export default function Header({
  activeRole,
  setActiveRole,
  activeBookingsCount,
  notifications,
  setShowNotifications,
  showNotifications
}) {
  const { isDarkMode, toggleDarkMode } = useTheme();

  const navRoles = [
    { id: 'driver', label: 'Find Parking', icon: Navigation, badge: activeBookingsCount },
    { id: 'owner', label: 'Host a Space', icon: Home },
    { id: 'admin', label: 'Admin Console', icon: Shield },
    { id: 'prd', label: 'Tech Specs', icon: FileText },
  ];

  return (
    <header className="bg-white/90 dark:bg-[#030712]/90 backdrop-blur-md sticky top-0 z-[100] border-b border-indigo-100/60 dark:border-slate-800 transition-colors duration-500">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-20 items-center">
          {/* Logo */}
          <div
            onClick={() => setActiveRole('driver')}
            className="flex items-center space-x-3 cursor-pointer group"
          >
            <div className="bg-gradient-to-br from-indigo-600 via-indigo-700 to-purple-600 p-2.5 rounded-2xl group-hover:rotate-12 transition-transform shadow-lg shadow-indigo-500/25">
              <Car className="h-6 w-6 text-white" />
            </div>
            <div>
              <span className="text-2xl font-black text-slate-900 dark:text-white tracking-tighter flex items-center gap-1.5 font-display">
                ParkSpot <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 inline-block animate-pulse"></span>
              </span>
              <p className="text-[10px] font-black text-indigo-500 dark:text-indigo-400 uppercase tracking-widest -mt-1">
                AI Transit & Slot Engine
              </p>
            </div>
          </div>

          {/* Role Navigation Pills */}
          <div className="hidden md:flex items-center space-x-1.5 bg-indigo-50/70 dark:bg-slate-900/80 p-1.5 rounded-2xl border border-indigo-100/60 dark:border-slate-800">
            {navRoles.map((role) => {
              const Icon = role.icon;
              const isActive = activeRole === role.id;

              return (
                <button
                  key={role.id}
                  onClick={() => setActiveRole(role.id)}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-xl text-xs font-black transition-all cursor-pointer ${
                    isActive
                      ? 'bg-gradient-to-r from-indigo-600 to-indigo-700 text-white shadow-md shadow-indigo-500/20'
                      : 'text-slate-600 dark:text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 hover:bg-white/60 dark:hover:bg-slate-800/60'
                  }`}
                >
                  <Icon className={`h-4 w-4 ${isActive ? 'text-white' : 'text-indigo-400'}`} />
                  <span>{role.label}</span>
                  {role.badge > 0 && (
                    <span className="px-2 py-0.5 rounded-full bg-emerald-500 text-white font-black text-[10px]">
                      {role.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Right Actions */}
          <div className="flex items-center space-x-3">
            {/* Theme Toggle Button */}
            <motion.button
              whileTap={{ scale: 0.9 }}
              onClick={toggleDarkMode}
              className="p-2.5 rounded-xl bg-indigo-50/80 dark:bg-slate-900 text-slate-600 dark:text-yellow-400 hover:bg-indigo-100 dark:hover:bg-slate-800 transition-all border border-indigo-100 dark:border-slate-800 shadow-sm cursor-pointer"
              title={isDarkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
            >
              {isDarkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
            </motion.button>

            {/* Notifications Toggle */}
            <div className="relative">
              <motion.button
                whileTap={{ scale: 0.9 }}
                onClick={() => setShowNotifications(!showNotifications)}
                className="p-2.5 rounded-xl bg-indigo-50/80 dark:bg-slate-900 text-slate-600 dark:text-slate-300 hover:bg-indigo-100 dark:hover:bg-slate-800 transition-all border border-indigo-100 dark:border-slate-800 shadow-sm relative cursor-pointer"
              >
                <Bell className="h-5 w-5 text-indigo-600 dark:text-indigo-400" />
                {notifications.length > 0 && (
                  <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-emerald-500 text-white text-[10px] font-black flex items-center justify-center border-2 border-white dark:border-slate-900">
                    {notifications.length}
                  </span>
                )}
              </motion.button>

              <AnimatePresence>
                {showNotifications && (
                  <motion.div
                    initial={{ opacity: 0, y: 10, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 10, scale: 0.95 }}
                    className="absolute right-0 mt-3 w-80 bg-white dark:bg-slate-900 border border-indigo-100 dark:border-slate-800 rounded-3xl shadow-2xl p-5 z-50 overflow-hidden"
                  >
                    <div className="flex items-center justify-between pb-3 border-b border-indigo-50 dark:border-slate-800 mb-3">
                      <h4 className="text-xs font-black text-slate-900 dark:text-white flex items-center gap-2 uppercase tracking-wider">
                        <Bell className="h-4 w-4 text-indigo-600" /> Live Alerts
                      </h4>
                      <span className="text-[10px] bg-emerald-500/10 text-emerald-600 px-2.5 py-1 rounded-full font-black">
                        {notifications.length} New
                      </span>
                    </div>
                    <div className="space-y-2.5 max-h-64 overflow-y-auto pr-1">
                      {notifications.map((n) => (
                        <div
                          key={n.id}
                          className="p-3 rounded-2xl bg-indigo-50/50 dark:bg-slate-800/80 border border-indigo-100/50 dark:border-slate-700/50 text-xs space-y-1"
                        >
                          <div className="flex justify-between font-black text-indigo-600 dark:text-indigo-400">
                            <span>{n.title}</span>
                            <span className="text-[10px] text-slate-400 font-mono">{n.time}</span>
                          </div>
                          <p className="text-slate-600 dark:text-slate-300 text-[11px] font-medium leading-relaxed">
                            {n.message}
                          </p>
                        </div>
                      ))}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Profile Pill */}
            <div className="hidden lg:flex items-center space-x-3 bg-gradient-to-r from-indigo-500/10 to-purple-500/10 border border-indigo-500/20 px-4 py-2 rounded-2xl">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-indigo-600 to-purple-600 text-white flex items-center justify-center font-black text-xs shadow-md shadow-indigo-500/20">
                P
              </div>
              <div className="text-left text-xs">
                <p className="font-black text-slate-900 dark:text-white leading-tight">Priya Sharma</p>
                <p className="text-emerald-600 dark:text-emerald-400 text-[10px] font-extrabold flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span> Verified Driver
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Mobile Navigation Bar */}
        <div className="md:hidden flex justify-around py-2.5 border-t border-indigo-100/60 dark:border-slate-800">
          {navRoles.map((role) => {
            const Icon = role.icon;
            const isActive = activeRole === role.id;
            return (
              <button
                key={role.id}
                onClick={() => setActiveRole(role.id)}
                className={`flex flex-col items-center p-2 rounded-xl text-[10px] font-black transition-all ${
                  isActive ? 'text-indigo-600 bg-indigo-50 dark:bg-slate-800' : 'text-slate-500 dark:text-slate-400'
                }`}
              >
                <Icon className="h-5 w-5 mb-0.5" />
                <span>{role.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
}
