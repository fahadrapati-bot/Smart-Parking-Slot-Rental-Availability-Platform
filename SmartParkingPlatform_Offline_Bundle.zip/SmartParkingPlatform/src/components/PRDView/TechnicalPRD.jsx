import React, { useState } from 'react';
import { FileText, Download, Copy, Check, Sparkles, BookOpen, Layers, ShieldCheck, Cpu } from 'lucide-react';
import { PRD_DOCUMENT_CONTENT } from '../../data/mockData';
import { motion } from 'framer-motion';

export default function TechnicalPRD() {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(PRD_DOCUMENT_CONTENT);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleDownload = () => {
    const element = document.createElement('a');
    const file = new Blob([PRD_DOCUMENT_CONTENT], { type: 'text/markdown' });
    element.href = URL.createObjectURL(file);
    element.download = 'Smart_Parking_Platform_PRD.md';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  return (
    <div className="space-y-10 max-w-5xl mx-auto pb-16">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-indigo-900 via-indigo-950 to-slate-950 dark:from-indigo-950 dark:to-slate-950 p-12 rounded-[50px] text-white flex flex-col md:flex-row items-start md:items-center justify-between shadow-2xl relative overflow-hidden group border border-indigo-500/20">
        <div className="relative z-10 space-y-3">
          <div className="flex items-center space-x-3">
            <span className="bg-indigo-500/20 text-indigo-300 px-4 py-1.5 rounded-full text-xs font-black uppercase tracking-widest border border-indigo-500/30">
              Official Spec
            </span>
            <span className="text-xs font-mono opacity-80">v1.0.4 • Updated Aug 2026</span>
          </div>
          <h1 className="text-4xl font-black tracking-tight font-display">Product Requirements (PRD)</h1>
          <p className="text-slate-300 text-lg font-medium max-w-xl">
            Unified Mentor Technical Specification & Architecture Manual
          </p>
        </div>

        <div className="mt-8 md:mt-0 relative z-10 flex items-center space-x-4">
          <button
            onClick={handleCopy}
            className="bg-white/10 hover:bg-white/20 text-white px-6 py-4 rounded-2xl font-black text-sm transition-all flex items-center space-x-2 backdrop-blur-md cursor-pointer border border-white/10"
          >
            {copied ? <Check className="h-5 w-5 text-emerald-400" /> : <Copy className="h-5 w-5 text-indigo-300" />}
            <span>{copied ? 'Copied Markdown!' : 'Copy Markdown'}</span>
          </button>

          <button
            onClick={handleDownload}
            className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-8 py-4 rounded-2xl font-black text-sm hover:scale-105 transition-all flex items-center space-x-2 shadow-xl cursor-pointer"
          >
            <Download className="h-5 w-5" />
            <span>Export PRD (.md)</span>
          </button>
        </div>
        <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl -mr-32 -mt-32 group-hover:scale-150 transition-transform duration-1000" />
      </div>

      {/* Rendered Content Card */}
      <div className="bg-white dark:bg-slate-900 p-12 rounded-[40px] border border-indigo-100/60 dark:border-slate-800 shadow-xl text-slate-800 dark:text-slate-200 text-sm space-y-10 leading-relaxed">
        <div>
          <h3 className="text-2xl font-black text-slate-900 dark:text-white border-b border-indigo-50 dark:border-slate-800 pb-4 mb-4 flex items-center space-x-3 font-display">
            <BookOpen className="h-7 w-7 text-indigo-600 dark:text-indigo-400" />
            <span>1. Executive Summary & Vision</span>
          </h3>
          <p className="text-slate-600 dark:text-slate-400 text-lg leading-relaxed font-medium">
            The <strong>Smart Parking Slot Rental & Availability Platform</strong> (ParkSpot AI) is a location-based digital solution enabling private parking space owners to rent out unused parking slots near metro stations, commercial centers, and IT hubs. Drivers can search, reserve, and manage parking slots in advance, eliminating cruising time, saving fuel, and reducing downtown traffic congestion.
          </p>
        </div>

        <div>
          <h3 className="text-2xl font-black text-slate-900 dark:text-white border-b border-indigo-50 dark:border-slate-800 pb-4 mb-4 flex items-center space-x-3 font-display">
            <Layers className="h-7 w-7 text-purple-500" />
            <span>2. Problem Statement & Strategic Scope</span>
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-rose-50 dark:bg-rose-950/20 p-8 rounded-3xl border border-rose-100 dark:border-rose-900/40">
              <h4 className="font-black text-rose-600 dark:text-rose-400 text-xs uppercase tracking-widest mb-3">
                Urban Commute Friction
              </h4>
              <ul className="space-y-2 text-xs text-rose-900 dark:text-rose-200 list-disc list-inside font-bold leading-relaxed">
                <li>Severe lack of structured parking near transit hubs</li>
                <li>Zero real-time visibility of empty parking bays</li>
                <li>Average 20 mins spent searching for parking daily</li>
                <li>Unused private driveways and commercial bays</li>
              </ul>
            </div>

            <div className="bg-emerald-50 dark:bg-emerald-950/20 p-8 rounded-3xl border border-emerald-100 dark:border-emerald-900/40">
              <h4 className="font-black text-emerald-600 dark:text-emerald-400 text-xs uppercase tracking-widest mb-3">
                Platform Solution Impact
              </h4>
              <ul className="space-y-2 text-xs text-emerald-900 dark:text-emerald-200 list-disc list-inside font-bold leading-relaxed">
                <li>Monetize underutilized private parking spaces</li>
                <li>Live real-time parking availability map</li>
                <li>Reduce downtown vehicle cruising & emissions</li>
                <li>Digital gate QR passes & transparent rates</li>
              </ul>
            </div>
          </div>
        </div>

        <div>
          <h3 className="text-2xl font-black text-slate-900 dark:text-white border-b border-indigo-50 dark:border-slate-800 pb-4 mb-4 flex items-center space-x-3 font-display">
            <Cpu className="h-7 w-7 text-emerald-500" />
            <span>3. Core Platform Modules</span>
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs">
            <div className="bg-indigo-50/30 dark:bg-slate-800/50 p-6 rounded-3xl border border-indigo-100/50 dark:border-slate-700/50 space-y-3">
              <h4 className="font-black text-indigo-600 dark:text-indigo-400 text-base">🚘 Driver Module</h4>
              <p className="text-slate-600 dark:text-slate-400 font-medium leading-relaxed">
                Geospatial search, vehicle filtering (2W/4W/EV), Leaflet interactive map pins, advance slot checkout, confetti confirmation, printable digital gate passes with QR tokens.
              </p>
            </div>

            <div className="bg-indigo-50/30 dark:bg-slate-800/50 p-6 rounded-3xl border border-indigo-100/50 dark:border-slate-700/50 space-y-3">
              <h4 className="font-black text-purple-500 text-base">🏠 Host Module</h4>
              <p className="text-slate-600 dark:text-slate-400 font-medium leading-relaxed">
                List new facilities, set hourly/daily/monthly pricing, manage slot locker availability, review driver booking requests, track earnings & revenue growth.
              </p>
            </div>

            <div className="bg-indigo-50/30 dark:bg-slate-800/50 p-6 rounded-3xl border border-indigo-100/50 dark:border-slate-700/50 space-y-3">
              <h4 className="font-black text-emerald-500 text-base">🛡️ Admin Console</h4>
              <p className="text-slate-600 dark:text-slate-400 font-medium leading-relaxed">
                Audit pending host applications, verify ownership documents, audit live network directories, track total platform volume and commissions.
              </p>
            </div>
          </div>
        </div>

        <div>
          <h3 className="text-2xl font-black text-slate-900 dark:text-white border-b border-indigo-50 dark:border-slate-800 pb-4 mb-4 flex items-center space-x-3 font-display">
            <ShieldCheck className="h-7 w-7 text-purple-500" />
            <span>4. Non-Functional & Architecture Specifications</span>
          </h3>
          <div className="bg-indigo-50/40 dark:bg-slate-800/50 p-8 rounded-3xl border border-indigo-100/50 dark:border-slate-700/50 space-y-3 font-mono text-xs text-slate-700 dark:text-slate-300">
            <p><strong className="text-indigo-600 dark:text-indigo-400">Performance SLA:</strong> Fast location search & geospatial query response under &lt; 1.5 seconds.</p>
            <p><strong className="text-indigo-600 dark:text-indigo-400">Security Architecture:</strong> Encrypted QR gate token generation, JWT auth, HTTPS SSL enforcement.</p>
            <p><strong className="text-indigo-600 dark:text-indigo-400">Technology Stack:</strong> HTML5, CSS3, Tailwind CSS v4, JavaScript, React.js 19, Vite 8, Leaflet Maps, Lucide Icons, Framer Motion.</p>
          </div>
        </div>
      </div>
    </div>
  );
}
