import React, { useState } from 'react';
import { ShieldCheck, CheckCircle2, XCircle, AlertTriangle, Users, MapPin, Activity, FileText, Database, Shield, Package, DollarSign } from 'lucide-react';
import { PENDING_OWNER_LISTINGS } from '../../data/mockData';

export default function AdminDashboard({ locations, setLocations }) {
  const [pendingListings, setPendingListings] = useState(PENDING_OWNER_LISTINGS);
  const [activeSubTab, setActiveSubTab] = useState('verification');

  const handleApprovePending = (item) => {
    const approvedLoc = {
      id: item.id,
      title: item.title,
      ownerId: 'owner-pending',
      ownerName: item.ownerName,
      ownerContact: item.ownerContact,
      rating: 5.0,
      reviewsCount: 0,
      verified: true,
      address: item.address,
      metroDistance: item.metroDistance,
      lat: 28.5500 + Math.random() * 0.1,
      lng: 77.2000 + Math.random() * 0.1,
      image: 'https://images.unsplash.com/photo-1590674899484-d5640e854abe?auto=format&fit=crop&w=1000&q=80',
      type: item.type,
      totalSlots: item.totalSlots,
      availableSlots: item.totalSlots,
      pricing: { hourly: item.requestedPricing, daily: item.requestedPricing * 8, monthly: 5000, currency: '₹' },
      allowedVehicles: item.vehicleTypes,
      amenities: ['CCTV', 'Verified Guard'],
      operatingHours: '06:00 AM - 11:00 PM',
      slots: Array.from({ length: item.totalSlots }, (_, i) => ({
        id: `N-${i + 1}`,
        type: '4-Wheeler',
        status: 'AVAILABLE',
        basePrice: item.requestedPricing
      }))
    };

    setLocations([approvedLoc, ...locations]);
    setPendingListings(pendingListings.filter((p) => p.id !== item.id));
    alert(`Listing "${item.title}" approved and published live to transit map!`);
  };

  const handleRejectPending = (id) => {
    setPendingListings(pendingListings.filter((p) => p.id !== id));
    alert('Listing application rejected with notice sent to owner.');
  };

  return (
    <div className="space-y-10">
      {/* Header */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div>
          <h1 className="text-4xl font-black text-slate-900 dark:text-white tracking-tight flex items-center space-x-3 font-display">
            <Shield className="h-10 w-10 text-emerald-500" />
            <span>Admin & Ops Console</span>
          </h1>
          <p className="text-slate-500 dark:text-slate-400 mt-2 text-lg font-medium">
            Verify space owner applications, audit citywide network directories, and manage platform safety
          </p>
        </div>

        <div className="flex items-center space-x-2 bg-white dark:bg-slate-900 p-2 rounded-2xl border border-indigo-100/60 dark:border-slate-800 shadow-sm">
          <button
            onClick={() => setActiveSubTab('verification')}
            className={`px-6 py-3 rounded-xl text-xs font-black transition-all cursor-pointer ${
              activeSubTab === 'verification'
                ? 'bg-emerald-500 text-white shadow-md shadow-emerald-500/20'
                : 'text-slate-600 dark:text-slate-400 hover:text-emerald-500'
            }`}
          >
            Verification Queue ({pendingListings.length})
          </button>
          <button
            onClick={() => setActiveSubTab('network')}
            className={`px-6 py-3 rounded-xl text-xs font-black transition-all cursor-pointer ${
              activeSubTab === 'network'
                ? 'bg-emerald-500 text-white shadow-md shadow-emerald-500/20'
                : 'text-slate-600 dark:text-slate-400 hover:text-emerald-500'
            }`}
          >
            Network Directory ({locations.length})
          </button>
        </div>
      </div>

      {/* Admin KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border border-indigo-100/60 dark:border-slate-800 shadow-sm dark:shadow-none">
          <div className="flex items-center justify-between mb-4">
            <Package className="h-8 w-8 text-emerald-500" />
            <span className="text-slate-400 dark:text-slate-500 text-xs font-black uppercase tracking-widest">
              Total Bays
            </span>
          </div>
          <span className="text-4xl font-black text-slate-900 dark:text-white font-mono">184 Bays</span>
          <p className="text-emerald-500 mt-2 text-xs font-bold">Across 5 Metro Hub Districts</p>
        </div>

        <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border border-indigo-100/60 dark:border-slate-800 shadow-sm dark:shadow-none">
          <div className="flex items-center justify-between mb-4">
            <DollarSign className="h-8 w-8 text-indigo-500" />
            <span className="text-slate-400 dark:text-slate-500 text-xs font-black uppercase tracking-widest">
              Volume
            </span>
          </div>
          <span className="text-4xl font-black text-slate-900 dark:text-white font-mono">₹4,28,900</span>
          <p className="text-indigo-500 mt-2 text-xs font-bold">Platform Revenue: ₹42,890 (10%)</p>
        </div>

        <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border border-indigo-100/60 dark:border-slate-800 shadow-sm dark:shadow-none">
          <div className="flex items-center justify-between mb-4">
            <Users className="h-8 w-8 text-purple-500" />
            <span className="text-slate-400 dark:text-slate-500 text-xs font-black uppercase tracking-widest">
              Hosts
            </span>
          </div>
          <span className="text-4xl font-black text-slate-900 dark:text-white font-mono">32 Owners</span>
          <p className="text-purple-500 mt-2 text-xs font-bold">100% ID Verified</p>
        </div>

        <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border border-indigo-100/60 dark:border-slate-800 shadow-sm dark:shadow-none">
          <div className="flex items-center justify-between mb-4">
            <AlertTriangle className="h-8 w-8 text-amber-500" />
            <span className="text-slate-400 dark:text-slate-500 text-xs font-black uppercase tracking-widest">
              Queue
            </span>
          </div>
          <span className="text-4xl font-black text-amber-500 font-mono">{pendingListings.length} Apps</span>
          <p className="text-amber-500 mt-2 text-xs font-bold">SLA Target: &lt; 2 Hours</p>
        </div>
      </div>

      {/* Verification Queue */}
      {activeSubTab === 'verification' && (
        <div className="space-y-6">
          <h3 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight font-display">
            Owner Space Verification Applications
          </h3>

          {pendingListings.length === 0 ? (
            <div className="bg-white dark:bg-slate-900 p-16 text-center rounded-[40px] border border-indigo-100/60 dark:border-slate-800 shadow-xl space-y-3">
              <CheckCircle2 className="h-16 w-16 text-emerald-500 mx-auto" />
              <p className="text-2xl font-black text-slate-900 dark:text-white">Verification Queue Clear!</p>
              <p className="text-slate-500 dark:text-slate-400 font-medium">
                All submitted parking space listings have been audited and published live.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-6">
              {pendingListings.map((item) => (
                <div
                  key={item.id}
                  className="bg-white dark:bg-slate-900 p-8 rounded-[40px] border border-indigo-100/60 dark:border-slate-800 shadow-sm space-y-6"
                >
                  <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 border-b border-indigo-50 dark:border-slate-800 pb-6">
                    <div>
                      <div className="flex items-center space-x-3 mb-2">
                        <h4 className="font-black text-xl text-slate-900 dark:text-white">{item.title}</h4>
                        <span className="bg-amber-500/10 text-amber-500 px-3 py-1 rounded-full text-xs font-black">
                          Pending Audit
                        </span>
                      </div>
                      <p className="text-xs text-slate-500 dark:text-slate-400 flex items-center space-x-1 font-medium">
                        <MapPin className="h-4 w-4 text-indigo-500" />
                        <span>{item.address} ({item.metroDistance})</span>
                      </p>
                    </div>

                    <div className="text-right">
                      <span className="text-[10px] text-slate-400 uppercase font-black tracking-widest block font-mono">
                        SUBMITTED
                      </span>
                      <span className="text-xs font-black text-slate-700 dark:text-slate-300">{item.submittedDate}</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs bg-indigo-50/40 dark:bg-slate-800/60 p-6 rounded-3xl">
                    <div>
                      <span className="text-slate-400 dark:text-slate-500 text-[10px] block font-black uppercase tracking-widest mb-1">
                        Owner Name
                      </span>
                      <span className="font-black text-slate-900 dark:text-white">{item.ownerName}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 dark:text-slate-500 text-[10px] block font-black uppercase tracking-widest mb-1">
                        Capacity
                      </span>
                      <span className="font-black text-indigo-600 dark:text-indigo-400">{item.totalSlots} Slots</span>
                    </div>
                    <div>
                      <span className="text-slate-400 dark:text-slate-500 text-[10px] block font-black uppercase tracking-widest mb-1">
                        Requested Rate
                      </span>
                      <span className="font-black text-emerald-500 font-mono">₹{item.requestedPricing}/hr</span>
                    </div>
                    <div>
                      <span className="text-slate-400 dark:text-slate-500 text-[10px] block font-black uppercase tracking-widest mb-1">
                        Documents
                      </span>
                      <span className="font-black text-purple-500">{item.documentsAttached.join(', ')}</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-end space-x-4 pt-2">
                    <button
                      onClick={() => handleRejectPending(item.id)}
                      className="bg-indigo-50/60 dark:bg-slate-800 text-rose-500 px-6 py-3 rounded-2xl text-xs font-black hover:bg-rose-500 hover:text-white transition-all cursor-pointer"
                    >
                      Reject Application
                    </button>
                    <button
                      onClick={() => handleApprovePending(item)}
                      className="bg-emerald-500 text-white px-8 py-3 rounded-2xl text-xs font-black hover:opacity-90 transition-all flex items-center space-x-2 cursor-pointer shadow-lg shadow-emerald-500/20"
                    >
                      <CheckCircle2 className="h-4 w-4" />
                      <span>Approve & Publish Live</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Network Directory */}
      {activeSubTab === 'network' && (
        <div className="bg-white dark:bg-slate-900 rounded-[40px] overflow-hidden border border-indigo-100/60 dark:border-slate-800 shadow-sm">
          <div className="p-8 border-b border-indigo-50 dark:border-slate-800">
            <h3 className="text-2xl font-black text-slate-900 dark:text-white font-display">Active Citywide Parking Directory</h3>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left font-medium">
              <thead className="bg-indigo-50/60 dark:bg-slate-800/80 border-b border-indigo-50 dark:border-slate-700/60">
                <tr>
                  <th className="px-8 py-6 text-xs font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest">
                    Facility Name
                  </th>
                  <th className="px-8 py-6 text-xs font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest">
                    Host
                  </th>
                  <th className="px-8 py-6 text-xs font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest">
                    Proximity
                  </th>
                  <th className="px-8 py-6 text-xs font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest">
                    Slots Capacity
                  </th>
                  <th className="px-8 py-6 text-xs font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest">
                    Rate
                  </th>
                  <th className="px-8 py-6 text-xs font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest">
                    Status
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-indigo-50 dark:divide-slate-800">
                {locations.map((loc) => (
                  <tr key={loc.id} className="hover:bg-indigo-50/30 dark:hover:bg-slate-800/50 transition-colors">
                    <td className="px-8 py-6 font-black text-slate-900 dark:text-white">{loc.title}</td>
                    <td className="px-8 py-6 text-slate-600 dark:text-slate-300">{loc.ownerName}</td>
                    <td className="px-8 py-6 text-indigo-600 dark:text-indigo-400 font-black">{loc.metroDistance}</td>
                    <td className="px-8 py-6 font-bold text-slate-900 dark:text-white">
                      {loc.totalSlots} Slots ({loc.availableSlots} free)
                    </td>
                    <td className="px-8 py-6 text-emerald-500 font-black font-mono">₹{loc.pricing.hourly}/hr</td>
                    <td className="px-8 py-6">
                      <span className="px-3.5 py-1.5 bg-emerald-500/10 text-emerald-500 rounded-full text-xs font-black uppercase tracking-wider">
                        ACTIVE
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
